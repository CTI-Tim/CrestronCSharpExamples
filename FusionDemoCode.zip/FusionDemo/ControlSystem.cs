﻿using System;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       				// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    		// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.GeneralIO;
using System.Collections.Generic;
using Crestron.SimplSharpPro.UC;

//-> Add to referneces the Crestron.SimplSharpPro.Fusion.dll
//-> Add with using the Fusion namespace to your project
using Crestron.SimplSharpPro.Fusion;

namespace FusionDemo
{
    public class ControlSystem : CrestronControlSystem
    {
        //-> Define a FusionRoom member
        public FusionRoom myRoom;

		public Dictionary<string, ushort> attrib = new Dictionary<string, ushort>();
		public string guid;
		public Am101 airMedia;
		public GlsOdtCCn Occ;

        public ControlSystem()
            : base()
        {
            CrestronConsole.AddNewConsoleCommand(setSigValue, "setSigValue", "", ConsoleAccessLevelEnum.AccessOperator);
            CrestronConsole.AddNewConsoleCommand(setAssetSigValue, "setAssetSigValue", "", ConsoleAccessLevelEnum.AccessOperator);
           
			Thread.MaxNumberOfUserThreads = 20;
        }

        public override void InitializeSystem()
        {

			//AM-101 stuff
			airMedia = new Am101(20, this);
			if (airMedia.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
			{
				ErrorLog.Error("AM-101 failed registration. Cause: {0}", myRoom.RegistrationFailureReason);
			}

			//event handeler
			airMedia.IpInformationChange += new IpInformationChangeEventHandler(airMedia_IpInformationChange);
			airMedia.OnlineStatusChange += new OnlineStatusChangeEventHandler(airMedia_OnlineStatusChange);

			//Occupancy Sensor
			Occ = new GlsOdtCCn(97, this);
			if(Occ.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
			{
					ErrorLog.Error("Occ failed registration. Cause: {0}", myRoom.RegistrationFailureReason);
			}

			//event handele
			Occ.GlsOccupancySensorChange +=new GlsOccupancySensorChangeEventHandler(Occ_GlsOccupancySensorChange);

			//Attribute dict
			attrib.Add("My Boolean Sig 1", 1);
			attrib.Add("My Integer Sig 1", 1);
			attrib.Add("My String Sig 1", 1);

			//make the first GUID different
			guid = Guid.NewGuid().ToString();
			string temp ="";

			//make GUID unque to processor and slot.
			guid = temp + "-" + guid + "-" + this.ProgramNumber.ToString();

            //-> Initialize myRoom
            //IP-ID, Control System, Name of the room and a random Guid or from a config file. 
            myRoom = new FusionRoom(0x04, this, "My test room", guid);

            //-> Add attributes / signals to the Fusion room
            //Data type of signal, Joinnumber-49 (if you have in Fusion 50, you must use in Simpl#Pro 1), Name of the attribute / signal and read/write, read or write
            myRoom.AddSig(eSigType.Bool, attrib["My Boolean Sig 1"], "My Boolean Sig 1", eSigIoMask.InputOutputSig);
			myRoom.AddSig(eSigType.UShort, attrib["My Integer Sig 1"], "My Integer Sig 1", eSigIoMask.InputOutputSig);
			myRoom.AddSig(eSigType.String, attrib["My String Sig 1"], "My String Sig 1", eSigIoMask.InputOutputSig);
            
            //-> Add StateChange to get signal changes from Fusion
            myRoom.FusionStateChange += new FusionStateEventHandler(myRoom_FusionStateChange);

            //-> Add asset to room
            //Asset type, unique ID within a room for the asset, name, your type definition, Guid (don't use the Guid from the room)
            myRoom.AddAsset(eAssetType.DemandResponse, 1, "DemandResponse", "Demand/Response", Guid.NewGuid().ToString());
            myRoom.AddAsset(eAssetType.DynamicAsset, 2, "DynamicAsset", "Dynamic Asset", Guid.NewGuid().ToString());
            myRoom.AddAsset(eAssetType.EnergyLoad, 3, "EnergyLoad", "Energy Load", Guid.NewGuid().ToString());
            myRoom.AddAsset(eAssetType.EnergySupply, 4, "EnergySupply", "Energy Supply", Guid.NewGuid().ToString());
            myRoom.AddAsset(eAssetType.HvacZone, 5, "HvacZone", "HVAC Zone", Guid.NewGuid().ToString());
            myRoom.AddAsset(eAssetType.LightingLoad, 6, "LightingLoad", "Lighting Load", Guid.NewGuid().ToString());
			myRoom.AddAsset(eAssetType.StaticAsset, 7, "AM-101", "Media Device", Guid.NewGuid().ToString());
			myRoom.AddAsset(eAssetType.OccupancySensor, 8, "Occupancy Sensor", "Occupancy", Guid.NewGuid().ToString());
            //-> Add attributes / signals to an asset
            //unique ID from asset, data typ of signal, Joinnumber-49 (if you have in Fusion 50, you must use in Simpl#Pro 1), Name of the attribute / signal and read/write, read or write
            myRoom.AddSig(2, eSigType.Bool, 1, "My DynamicAsset Asset Asset Bool Sig 1", eSigIoMask.InputOutputSig);
            myRoom.AddSig(2, eSigType.UShort, 1, "My DynamicAsset Asset Asset UShort Sig 1", eSigIoMask.InputOutputSig);
			myRoom.AddSig(2, eSigType.String, 1, "My DynamicAsset Asset Asset String Sig 1", eSigIoMask.InputOutputSig);

			myRoom.AddSig(7, eSigType.String, 1, "AM-101 IP Address", eSigIoMask.InputSigOnly);

            //-> Add AssetStateChange to get signal changes from assets
            myRoom.FusionAssetStateChange += new FusionAssetStateEventHandler(myRoom_FusionAssetStateChange);

            //-> Register Fusion room
            if (myRoom.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                ErrorLog.Error("fusion failed registration. Cause: {0}", myRoom.RegistrationFailureReason);

            //-> Generate the RVI file for symbol discover
            FusionRVI.GenerateFileForAllFusionDevices();
        }

		void Occ_GlsOccupancySensorChange(GlsOccupancySensorBase device, GlsOccupancySensorChangeEventArgs args)
		{
			//throw new NotImplementedException();
			FusionOccupancySensor myAsset = (FusionOccupancySensor)myRoom.UserConfigurableAssetDetails[8].Asset;
			if (device.OccupancyDetectedFeedback.BoolValue== true)
			{
				//FusionOccupancySensor myAsset = (FusionOccupancySensor)myRoom.UserConfigurableAssetDetails[8].Asset;

				myAsset.RoomOccupied.InputSig.BoolValue = true;

			}
			else if (device.OccupancyDetectedFeedback.BoolValue == false)
			{
				//FusionOccupancySensor myAsset = (FusionOccupancySensor)myRoom.UserConfigurableAssetDetails[8].Asset;

				myAsset.RoomOccupied.InputSig.BoolValue = false;

			}
		}

		void airMedia_OnlineStatusChange(GenericBase currentDevice, OnlineOfflineEventArgs args)
		{
			//throw new NotImplementedException();
			if (args.DeviceOnLine == true)
			{
				FusionStaticAsset myAsset = (FusionStaticAsset)myRoom.UserConfigurableAssetDetails[7].Asset;

				myAsset.FusionGenericAssetSerialsAsset3.UserDefinedStringSigDetails[1].InputSig.StringValue = airMedia.IPAddressFeedback.ToString();

			}
		}

		void airMedia_IpInformationChange(GenericBase currentDevice, ConnectedIpEventArgs args)
		{
			//throw new NotImplementedException();
			if (args.Connected == true)
			{
				FusionStaticAsset myAsset = (FusionStaticAsset)myRoom.UserConfigurableAssetDetails[7].Asset;

				myAsset.FusionGenericAssetSerialsAsset3.UserDefinedStringSigDetails[1].InputSig.StringValue = airMedia.IPAddressFeedback.ToString();

			}
		}

        public void setSigValue(string command)
        {
            //-> Set value for predefined sig
            myRoom.SystemPowerOn.InputSig.BoolValue = true;
			myRoom.LogText.InputSig.StringValue = "Message|Data1|Data2|Data3|Data4";
			myRoom.DeviceUsage.InputSig.StringValue = "";
			myRoom.DisplayUsage.InputSig.UShortValue = 123;
			myRoom.ErrorMessage.InputSig.StringValue = "";
			CrestronConsole.Print(guid);

            //-> Set value for user defined attributes / signals
			myRoom.UserDefinedBooleanSigDetails[attrib["My Boolean Sig 1"]].InputSig.BoolValue = true;
			myRoom.UserDefinedUShortSigDetails[attrib["My Integer Sig 1"]].InputSig.UShortValue = 123;
			myRoom.UserDefinedStringSigDetails[attrib["My String Sig 1"]].InputSig.StringValue = "Hello";
        }

        public void setAssetSigValue(string command)
        {
            //-> Get asset from Fusion room and cast the asset, depending on the type you have defined.
            FusionLightingLoad myAsset = (FusionLightingLoad)myRoom.UserConfigurableAssetDetails[6].Asset;

            //-> Set value for predefined sig in the asset
            myAsset.LoadOn.InputSig.BoolValue = true;
            myAsset.LoadLevel.InputSig.UShortValue = 123;
            myAsset.RealTimePower.InputSig.UShortValue = 5000;

            // ---------------------------------------------------------

            //-> Get asset from Fusion room and cast the asset, depending on the type you have defined.
            FusionDynamicAsset myAsset2 = (FusionDynamicAsset)myRoom.UserConfigurableAssetDetails[2].Asset;

            //-> Set value for user defined sig in the asset
            myAsset2.FusionGenericAssetDigitalsAsset1.UserDefinedBooleanSigDetails[1].InputSig.BoolValue = true;
            myAsset2.FusionGenericAssetAnalogsAsset2.UserDefinedUShortSigDetails[1].InputSig.UShortValue = 123;
            myAsset2.FusionGenericAssetSerialsAsset3.UserDefinedStringSigDetails[1].InputSig.StringValue = "Hello";
        }

        //-> sig changes from the Fusion room directly
        void myRoom_FusionStateChange(FusionBase device, FusionStateEventArgs args)
        {
            switch (args.EventId)
            {
                case FusionEventIds.UserConfiguredBoolSigChangeEventId:
                    //-> determine which bool sig has changed
					if (args.UserConfiguredSigDetail == myRoom.UserDefinedBooleanSigDetails[attrib["My Boolean Sig 1"]])
                    {
                        //-> boolean (digital) signals will go true, then false when changed from fusion's web application. only respond to one transition of the signal
                        if (((BooleanSigData)args.UserConfiguredSigDetail).OutputSig.BoolValue)
                        {
                            CrestronConsole.PrintLine("Fusion room - bool value trigger");
                        }
                    }
                    break;

                case FusionEventIds.UserConfiguredUShortSigChangeEventId:
                    //-> determine which ushort sig has changed
                    if (args.UserConfiguredSigDetail == myRoom.UserDefinedUShortSigDetails[1])
                    {
                        CrestronConsole.PrintLine("Fusion room - ushort value: " + ((UShortSigData)args.UserConfiguredSigDetail).OutputSig.UShortValue);
                    }
                    break;

                case FusionEventIds.UserConfiguredStringSigChangeEventId:
                    //-> determine which string sig has changed
                    if (args.UserConfiguredSigDetail == myRoom.UserDefinedStringSigDetails[1])
                    {
                        CrestronConsole.PrintLine("Fusion room - string value: " + ((StringSigData)args.UserConfiguredSigDetail).OutputSig.StringValue); 
                    }
                    break;

                case FusionEventIds.SystemPowerOffReceivedEventId:
                    {
                        CrestronConsole.PrintLine("Fusion room - system off");
                        break;
                    }

                case FusionEventIds.SystemPowerOnReceivedEventId:
                    {
                        CrestronConsole.PrintLine("Fusion room - system on");
                        break;
                    }
            }
        }

        //-> sig changes from assets connected to a fusin room
        void myRoom_FusionAssetStateChange(FusionBase device, FusionAssetStateEventArgs args)
        {
            //-> check from which assset the value is coming.
            //In this case from asset 2 (DynamicAsset)
            if (args.UserConfigurableAssetDetailIndex == 2)
            {
                //-> check the type/event of the value
                switch (args.EventId)
                {
                    case FusionAssetEventId.DynamicAssetAssetBoolAssetSigEventReceivedEventId:
                        if(((BooleanSigData)args.UserConfiguredSigDetail).Number == 1)
                        {
                            //-> boolean (digital) signals will go true, then false when changed from fusion's web application. only respond to one transition of the signal
                            if (((BooleanSigData)args.UserConfiguredSigDetail).OutputSig.BoolValue)
                            {
                                CrestronConsole.PrintLine("Dynamic asset - Bool value trigger");   
                            }
                        }
                        break;
                    case FusionAssetEventId.DynamicAssetAssetUshortAssetSigEventId:
                        if (((UShortSigData)args.UserConfiguredSigDetail).Number == 1)
                        {
                            CrestronConsole.PrintLine("Dynamic asset - UShort value: " + ((UShortSigData)args.UserConfiguredSigDetail).OutputSig.UShortValue); 
                        }
                        break;
                    case FusionAssetEventId.DynamicAssetAssetStringAssetSigEventId:
                        if (((StringSigData)args.UserConfiguredSigDetail).Number == 1)
                        {
                            CrestronConsole.PrintLine("Dynamic asset - String value: " + ((StringSigData)args.UserConfiguredSigDetail).OutputSig.StringValue);
                        }
                        break;
                }
            }
            else if (args.UserConfigurableAssetDetailIndex == 6)
            {
                switch (args.EventId)
                {
                    case FusionAssetEventId.LoadLevelReceivedEventId:
                        CrestronConsole.PrintLine("LightingLoad - Load level: " + ((UShortSigDataFixedName)args.UserConfiguredSigDetail).OutputSig.UShortValue);
                        break;
                    case FusionAssetEventId.LoadOnReceivedEventId:
                        CrestronConsole.PrintLine("LightingLoad - Load On: " + ((BooleanSigDataFixedName)args.UserConfiguredSigDetail).OutputSig.BoolValue);
                        break;
                    case FusionAssetEventId.LoadOffReceivedEventId:
                        CrestronConsole.PrintLine("LightingLoad - Load Off:" + ((BooleanSigDataFixedName)args.UserConfiguredSigDetail).OutputSig.BoolValue);
                        break;
                }
            }
        }
    }
}
