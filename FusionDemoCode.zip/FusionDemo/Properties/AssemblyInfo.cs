﻿using System.Reflection;

[assembly: AssemblyTitle("FusionDemo")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("FusionDemo")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyVersion("1.0.0.*")]

