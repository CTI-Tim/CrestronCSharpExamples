﻿// You need your own API key
// https://api.openweathermap.org/data/2.5/weather?zip=32712&units=imperial&mode=xml&appid=<Your OpenWeathermap.org API key>
// Go to Openweathermap.org create a login and your own API key
// This only extracts some of the information. You can expand this to extract all th e weather information presented.
//
// This was written very "flat file" style so that Simpl+ and 301 programmers can follow along easier. More Object Oriented way of 
// Writing this would be to make the https get methog more generic to be re-useable and on it's own. as well as the parsing of the information to be
// a seperate method as well all called from an over all method that triggers those.  This would allow for the library to have easier managability
// and expandability in the future.  Rewriting this to be more modular and Object oriented would be a very good exercise for a new to C# programmer. Seperate out the https connection
// From the parsing of the data and have both of those as private methods called by a 3rd public method that executes them in order.
//

using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using System.Collections.Generic;
using Crestron.SimplSharp.Net.Https;                                // WE need to talk to encrypted web pages
using Crestron.SimplSharp.CrestronXml;                              // Makes it a LOT easier to decode XML


namespace OpenWeatherCrestron
{
    public delegate void DelegateTemplate(ushort Value); // Create our delegate template.  you do not use this in S+
    // The delegate definition is it's own class and can exist outside of your library class that you will use.
    // NOTE: the S+ API will show this as if it is a part of your class.  This will trip up a lot of programmers.
    // Do not ty and use this in your S+  it will throw ambigous errors that do not point at you using the wrong delegate name.

    public class Weather  
    {
        // Property to allow the s+ module to set the API key
        public string APIKey { get; set; }
        // Properties to allow S+ to read them but only this class can set them.
        // There is no reason to allow s+ to set any of these
        public string Temperature { get; private set; }
        public string TemperatureMin { get; private set; }
        public string TemperatureMax { get; private set; }
        public string CurrentWeather { get; private set; }
        public string Humidity { get; private set; }
        public string Wind { get; private set; }
        public string CityName { get; private set; }
        // Lets also offer up the temperature and humidity as  numbers
        public ushort TempVal { get; private set; }
        public ushort TempMaxVal { get; private set; }
        public ushort TempMinVal { get; private set; }
        public ushort HumidVal { get; private set; }

        // Create the delegate we will actually use in S+  This is the Name you will use in Simpl+
        public DelegateTemplate WeatherDelegate { get; set; }


        
        /// <summary>
        /// SIMPL+ can only execute the default constructor. If you have variables that require initialization, please
        /// use an Initialize method that you call on your own in S+  S+ cannot execute the default constructor if it has
        /// any parameters.  do not add anything in between the () or you cannot use this library in S+
        /// </summary>
        public Weather()
        {
        }
        /// <summary>
        ///  Connect and retrieve the weather conditions for the zip code selected
        /// </summary>
        /// <param name="ZipCode"></param>
        /// <param name="CountryCode"></param>
        public void Get( string ZipCode, string CountryCode )
        {
            string Wind = "";

            if (CountryCode.Length < 2)  // check if there is something there
            {
                CountryCode = "us";  // set to a default of USA
            }

            var Mode = "xml"; // Tell OpenWeather to give us a XML return payload

            var url = "https://api.openweathermap.org/data/2.5/weather?zip=" + ZipCode + "," + CountryCode.ToLower() + "&units=imperial"+ "&mode=" + Mode + "&appid=" + APIKey;

            // WE are going to do a https request.   we create the client, request, set it to not be keep alive, and parse the URL to get ready

            var client = new HttpsClient();
            var request = new HttpsClientRequest();

            client.KeepAlive = false;
            request.ContentString = "";
            request.RequestType = RequestType.Get;
            request.Url.Parse(url);

            // We are now ready, send the request to the website and get the page back.
            var response = client.Dispatch(request);

            //CrestronConsole.PrintLine("Got {0} : {1} length  XML:  {2}", response.Code, response.ContentLength, response.ContentString);

#region "Xml Document Example Comment"
            /*  //  Example of the XML that you will get as of Nov-2021
            <current>
                <city id="0" name="Schenectady">
                    <coord lon="-73.9396" lat="42.8142"/>
                    <country>US</country>
                    <timezone>-18000</timezone>
                    <sun rise="2021-11-11T11:43:00" set="2021-11-11T21:36:46"/>
                </city>
                <temperature value="36.61" min="28.62" max="43.25" unit="Fahrenheit"/>
                <feels_like value="36.61" unit="Fahrenheit"/>
                <humidity value="93" unit="%"/>
                <pressure value="1027" unit="hPa"/>
                <wind>
                    <speed value="0" unit="mph" name="Setting"/>
                    <gusts/>
                    <direction/>
                </wind>
                <clouds value="1" name="clear sky"/>
                <visibility value="10000"/>
                <precipitation mode="no"/>
                <weather number="741" value="fog" icon="50d"/>
                <lastupdate value="2021-11-11T13:31:53"/>
            </current> 
             */
#endregion

            if (response.Code == 200)        // If we actually connected and got a page, we will get code 200
            {

                string s = response.ContentString;     //store the response
                var myXMLReader = new XmlReader(s);     // Load the string into the XML reader so we can easily parse the information

                myXMLReader.MoveToFirstAttribute();     // This makes sure we are at the very beginning of the XML

                while (myXMLReader.Read())              // WE now iterate through the whole XML reading each node.
                {
                    if (myXMLReader.NodeType == XmlNodeType.Element)     // Is this an XML element?
                    {
                        switch (myXMLReader.Name.ToLower())
                        {
                            case "city":
                                {
                                    if (myXMLReader.HasAttributes)      // <temperature value="66.85" min="64.63" max="69.51" unit="Fahrenheit"/> Value, min, max, unit all are attributes
                                    {
                                        while (myXMLReader.MoveToNextAttribute())
                                        {
                                            if (myXMLReader.Name.ToLower() == "name")
                                            {
                                                CityName = myXMLReader.Value;  //  If the attribute we are on right now is called name, extract it's value.
                                            }
                                        }
                                    }
                                    break;
                                }
                            case "temperature":
                                {
                                    if (myXMLReader.HasAttributes)
                                    {
                                        while (myXMLReader.MoveToNextAttribute())   // We want to read all the attributes inside this tag.
                                        {

                                            switch (myXMLReader.Name.ToLower())
                                            {
                                                case "value":
                                                    Temperature = myXMLReader.Value;
                                                    TempVal = (ushort)(10 * float.Parse(myXMLReader.Value)); // Times 10 to get at least 1 decimal place of accuracy to s+ and match other Simpl code
                                                    break;
                                                case "min":
                                                    TemperatureMin = myXMLReader.Value;
                                                    TempMinVal = (ushort)(10 * float.Parse(myXMLReader.Value));
                                                    break;
                                                case "max":
                                                    TemperatureMax = myXMLReader.Value;
                                                    TempMaxVal = (ushort)(10 * float.Parse(myXMLReader.Value));
                                                    break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            case "humidity":
                                {
                                    if (myXMLReader.HasAttributes)
                                    {
                                        while (myXMLReader.MoveToNextAttribute())
                                        {
                                            if (myXMLReader.Name.ToLower() == "value")
                                            {
                                                Humidity = myXMLReader.Value;
                                                HumidVal = (ushort)float.Parse(myXMLReader.Value);

                                            }
                                        }
                                    }
                                    break;
                                }
                            case "weather":
                                {
                                    if (myXMLReader.HasAttributes)
                                    {
                                        while (myXMLReader.MoveToNextAttribute())
                                        {
                                            if (myXMLReader.Name.ToLower() == "value")
                                            {
                                                CurrentWeather = myXMLReader.Value;

                                            }
                                        }
                                    }
                                    break;
                                }
                            case "wind":
                                {
                                    if (myXMLReader.HasAttributes)
                                    {
                                        while (myXMLReader.MoveToNextAttribute())
                                        {
                                            switch (myXMLReader.Name.ToLower())
                                            {
                                                case "value":
                                                    Wind = myXMLReader.Value;
                                                    break;
                                                case "unit":
                                                    Wind = Wind + " " + myXMLReader.Value;
                                                    break;
                                                case "name":
                                                    Wind = Wind + " " + myXMLReader.Value;
                                                    break;


                                            }
                                        }
                                    }
                                    break;
                                }
                        }
                    }
                }
                WeatherDelegate(1); // Send a 1 telling our Simpl+ that we were sucessful in getting weather info
            }
            else
            {
                WeatherDelegate(0); // Send a 0 telling Simpl+ that we failed at getting the weather.
            }
        }
    }
}
