﻿using System.Reflection;

[assembly: AssemblyTitle("OpenWeatherCrestron")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OpenWeatherCrestron")]
[assembly: AssemblyCopyright("Copyright ©  2021")]
[assembly: AssemblyVersion("1.0.0.*")]

