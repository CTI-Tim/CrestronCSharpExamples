﻿using System.Reflection;

[assembly: AssemblyTitle("ComEdCurrentHourAverage")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ComEdCurrentHourAverage")]
[assembly: AssemblyCopyright("Copyright ©  2024")]
[assembly: AssemblyVersion("1.0.0.*")]

