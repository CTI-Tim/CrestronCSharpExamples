﻿using System;
using Crestron.SimplSharp; // For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;


namespace ComEdCurrentHourAverage
{
    public class ComEd
    {
        public string Result { get; private set; }

        public void GetHourAverage() 
        {
            //  This is an extremely simple https client. This is blocking so that means it will sit here until we get data from the website
            // In a C# program this is BAD and should be spun up in a thread.
            // In a Simpl+ module this is just fine as S+ instances are threaded on their own already.

            var client = new HttpsClient();
            client.KeepAlive = false;


            // This is where the actual request is created and sent this will send back XML with the URL supplied
            // Crestrons https library is slightly broken so it will throw invisible exceptions you can not see in the processor
            // Have to catch them yourself.  this will probably never be fixed,  use the standard C# https on 4 series
            try
            {
                var request = new HttpsClientRequest();
                request.Url.Parse("https://hourlypricing.comed.com/api?type=currenthouraverage");
                request.ContentString = "";
                request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
                
                HttpsClientResponse response = client.Dispatch(request);
                Result = response.ContentString;
                CrestronConsole.PrintLine(" HTTP Returned = {0}", Result);
            }
            catch (Exception)
            {

                CrestronConsole.PrintLine("Threw invisible exception");
            }
            
        }
    }
}
