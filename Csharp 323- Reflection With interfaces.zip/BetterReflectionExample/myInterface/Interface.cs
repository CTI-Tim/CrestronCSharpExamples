﻿using System;

namespace myInterface
{
    public interface IpluginInterface
    {
        // here we create our template of what we are going to use as out interface to the class via reflection
        // this MUST match exactly in all cases.  This is why we created a separate library that we will include with the 
        // "drivers" or libraries we are going to reflect into our program and the program.
        int a { get; set; }
        string name { get; set; }
        void myMethod();
        void AnotherMethod(int i);

        // Dont forget you must add this as a dependency to the driver and the program
        //In order to make it available
    }
}
