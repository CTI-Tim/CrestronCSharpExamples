﻿using System;
using System.Reflection;    // we need this for Reflection
using myInterface;          //Bring in our Interface

namespace BetterReflectionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--Reflection Demo using Interfaces Started--");

            // Load our DLL  note: path is hardcoded for use in this example
            var myDll = Assembly.LoadFrom(@"..\..\..\..\myLibrary\bin\Debug\netcoreapp3.1\myLibrary.dll");

            foreach (var type in myDll.GetTypes())  //List what we have available inside the DLL
            {
                Console.WriteLine("Found {0} inside the DLL", type.FullName);
            }

            Type[] myType = myDll.GetTypes(); //Above we listed the contents, here we are loading them into an array
            //  because our dll is written by us we can make assumptions.  the Class that matches our Interface is the 
            //  first one to be found so that is the one we are going to use. If not then more code would be required to ensure 
            // we use the proper class.

            // We now need to create an instance of the class we want inside that dll and leverage the interface we have in common with it
            // using the reflection activator and creating an instance of the object we loaded into the array,  we want to only load what
            // is at index 0 as that is the first class.   WE should validate that it is a class.
            if (myType[0].IsClass == true)  // Is this a Class?
            {
                IpluginInterface myDevice = (IpluginInterface)Activator.CreateInstance(myType[0]);

                // We can now access the reflected class as if it was a standard class in our solution.

                myDevice.a = 4;  // we Just set the field a to int 4
                myDevice.name = "Fred";  // Set the name field
                myDevice.myMethod();  // Calling a blind method
                myDevice.AnotherMethod(99); // passing an integer

            }
            else
            {
                Console.WriteLine("First Type in the assembly list was not a class");
            }

            

            



        }
    }
}
