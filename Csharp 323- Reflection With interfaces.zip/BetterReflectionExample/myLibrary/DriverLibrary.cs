﻿using System;
using myInterface;

namespace myLibrary

{
    /// <summary>
    ///  At a Minimum we need to exactly match what we specified in the Interface.
    ///  We can add in more methods and fields and properties but they will not be 
    ///  easily accessed via the interface.  if you need internal methods feel free to create them.
    /// </summary>
    public class DriverLibrary : IpluginInterface  // We attach the interface to this class. now we can use it to make reflection easier
    {
        public int a { get; set; }  // create a couple of fields to save information
        public string name { get; set; }

        public DriverLibrary() // Default Constructor
        {
            Console.WriteLine("DriverLibrary has been instantiated");
        }
        public void myMethod()  // Our first method, it's only going to print info 
        {
            if(this.name.Length > 1)
            {
                Console.WriteLine(" The Library Field name contains : {0}",this.name);
            }
            else
            {
                Console.WriteLine("Library field name is currently empty");
            }
        }
        public void AnotherMethod(int i)  // This method takes an integer and will do math on the other field
        {
            Console.WriteLine(" the method was sent {0} and that number plus the library field a added is {1}",i,i+this.a);
        }

    }
}
