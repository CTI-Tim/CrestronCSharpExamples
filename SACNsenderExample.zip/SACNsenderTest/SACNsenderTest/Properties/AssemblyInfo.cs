﻿using System.Reflection;

[assembly: AssemblyTitle("SACNsenderTest")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SACNsenderTest")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyVersion("1.0.0.*")]

