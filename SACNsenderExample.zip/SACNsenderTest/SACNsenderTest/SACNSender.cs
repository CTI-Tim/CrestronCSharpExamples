﻿using System;
//using System.Net.Sockets;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronSockets;  // we do not have a UDP client for some silly reason. so we use the server.
using Crestron.SimplSharpPro.CrestronThread;


namespace SACNsenderTest
{
    public class SACNSender
    {
        // Written by Tim Gray Sr Technical Trainer at Crestron CTI as an example for programmers learning how to write classes to act as drivers for types of hardware
        // There is ZERO warranty to this module.  There is zero tech support for this module.  Do not call true blue support about it.
        // This is for learning purposes only.

        // This module demonstrates for 3 series how to do a UDP Client to spray UDP packets at a SACN E131 Ethernet to DMX gateway. It leverages threads and converts strings to byte arrays
        // NOTE that a specific codepage is used. this is for simplicity as that is a 8 bit codepage that supports all 255 characters.   Codepages and strings in C# are extrememly powerful
        // Compared to S+ it's a major learning step for programmers new to C#

        // Constants with "magic numbers"  Because there really is no reason to make these dynamic.  99.9% of the time it's these values
        // Yes I stole this directly from the Crestron SACN Simpl Plus module
        // SACN protocol is actually pretty simple, the documentation out there on it can be a bit confusing
        private const string HeaderString1 = "\x00\x10\x00\x00\x41\x53\x43\x2d\x45\x31\x2e\x31\x37\x00\x00\x00\x72\x6e\x00\x00\x00\x04\xfd\xd3\xaa\xe2\x04\x94\x48\xb7\x9b\xe4\xcc\xa9\x39\x0a\xe0\x47\x72\x58\x00\x00\x00\x02\x53\x41\x43\x4e\x56\x69\x65\x77\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x64\x00\x00\x00\x00";
        private const string HeaderString2 = "\x72\x0b\x02\xa1\x00\x00\x00\x01\x02\x01\x00";
        // Create our class globals  
        byte[] DMXChannels;
        ushort _universe;
        int _port;
        string _address;
        

        private UDPServer udpServer;

        Thread Sender;
        bool ThreadRun = false;

        /// <summary>
        ///  SACN Sender class for a single device.  If you need more devices or more universes them make more copies
        /// </summary>
        /// <param name="Address"> the IP address the UDP data will be sent to.  Direct or multicast address</param>
        /// <param name="Universe"> Universe number for DMX. universes number from 1 to 63,999</param>
        public SACNSender(string Address, ushort Universe)
        {
            // In sACN 1.31, universes number from 1 to 63,999. There are 64,000 unique numbers. 
            // The standard reserves the values of 0 and 64,000 to 65,535 for future expansion
            if( Universe < 1 || Universe > 63999 ) 
                    Universe = 1;

            _universe = Universe;
            // create and initalize the byte array
            DMXChannels = new byte[513];
            for(var i=0;i<512;i++)
                DMXChannels[i] = 0x00;

            _port = 5568;   // Fixed port.   It's not reccomended to change from this and some devices will not let you. so hardcoding this one is a good idea.
            _address = Address;

            udpServer = new UDPServer(_address, _port, 1024, EthernetAdapterType.EthernetLANAdapter);  // Create our server
            udpServer.EnableUDPServer();

            //Sender = new Thread(TimerWorker, null, Thread.eThreadStartOptions.CreateSuspended); // Creat our thread but do not start it
        }

        // Deconstructor to cleanly shut things down.   Ever have a C# program on a processor take forever to stop?   It's because the programmer did not clean up
        // by adding a deconstructor to make sure threads are shut down.
         ~SACNSender()
        {
            Stop();

            udpServer.DisableUDPServer();
            Sender.Abort();
            
        }
        /// <summary>
        ///  Manually push updates to the SACN device
        /// </summary>
        public void Send()
        {  
            // lets get our universe bytes
            char hiByteChar = Convert.ToChar((byte)(_universe >> 8));
            char loByteChar = Convert.ToChar((byte)(_universe & 0xFF));
            
            // Assembly the whole payload
            string temp = HeaderString1 + hiByteChar + loByteChar + HeaderString2 + System.Text.Encoding.GetEncoding(28591).GetString(DMXChannels, 0, DMXChannels.Length);
            byte[] payload = System.Text.Encoding.GetEncoding(28591).GetBytes(temp);
            
            IPEndPoint ipe = new IPEndPoint(IPAddress.Parse(_address), _port);
            SocketErrorCodes error = udpServer.SendData(payload, payload.Length, ipe);
            if (error != SocketErrorCodes.SOCKET_OK)
                CrestronConsole.PrintLine(" UDP Socket error : {0}", error);
        }
        /// <summary>
        /// Sets a single DMX channel to the value specified.
        /// </summary>
        /// <param name="channel">DMX channel number 1-511</param>
        /// <param name="value">Level 0-255</param>
        public void SetChannel(int channel, byte value)
        {
            if(channel < 1 || channel > 511)  // Address 0 and 512 are invalid
                channel = 1;

            DMXChannels[channel - 1] = value;
        }

        /// <summary>
        ///  Sets the chosen and next 2 channels to the R G and B values
        /// </summary>
        /// <param name="channel">DMX channel number to start at</param>
        /// <param name="red">red 0-255</param>
        /// <param name="green">green 0-255</param>
        /// <param name="blue">blue 0-255</param>
        public void SetRGB(int channel, byte red, byte green, byte blue)
        {
            if (channel < 1 || channel > 509)  // this sets three so 509 is the highest we can go
                channel = 1;
            channel = channel - 1;
            DMXChannels[channel] = red;
            DMXChannels[channel + 1] = green;
            DMXChannels[channel + 2] = blue;
        }
        /// <summary>
        ///  Sets the channel chosen and the next to to the R G and B values found in a Hex String
        /// </summary>
        /// <param name="channel">DMX channel number to start at</param>
        /// <param name="HexColor"> Hex representation of the color RRGGBB or #RRGGBB</param>
        public void SetRGB(int channel, String HexColor)
        {
            if (channel < 1 || channel > 509)  // this sets three so 509 is the highest we can go
                channel = 1;
            channel = channel - 1;

            HexColor = HexColor.TrimStart('#');  // get rid of # if it's there
            byte red = byte.Parse(HexColor.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
            byte green = byte.Parse(HexColor.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            byte blue = byte.Parse(HexColor.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);

            DMXChannels[channel] = red;
            DMXChannels[channel + 1] = green;
            DMXChannels[channel + 2] = blue;
        }
        /// <summary>
        /// Set all DMX channels of the chosen universe to 0x00
        /// </summary>
        public void AllOff()
        {
            for (var i = 0; i < 511; i++)
                DMXChannels[i] = 0x00;
            Send();
        }
        /// <summary>
        ///  Start automatic every 60ms updates to SACN device
        /// </summary>
        public void Start()
        {
            ThreadRun = true;
            Sender = new Thread(TimerWorker, null, Thread.eThreadStartOptions.CreateSuspended); // Creat our thread but do not start it. we recreate the thread over and over so it can be started and stopped and restarted
            Sender.Start(); // you could have created the thread started and skipped this.
        }
        /// <summary>
        ///  Stop the automatic updates.  Some devices return to default operation when they stop getting packets
        /// </summary>
        public void Stop()
        {
            ThreadRun = false;
            //Sender.Abort();
        }

        // This is the worker thread to send the byte array every 60ms
        /*
         * Notes on threading:   It's not hard.  Contrary to all the misinformation and fear all over the internet about threading, it is not hard at all. A Thread
         * is simply a method you call and tell it to do it on it's own over there and not block your main programs execution, it runs on it's own.    What is hard is managing data.   If your thread is modifying data
         * then you can run into problems where it can get changed at the wrong time.  It is up to you to manage this.  do not expect a variable to be set in stone
         * when you have a thread that can modify it. and if your thread is modifying things, have proper communication and leverage semaphores.
         * https://docs.microsoft.com/en-us/dotnet/api/system.threading.semaphore?view=net-6.0
         * 
         */

        private object TimerWorker(object o)
        {
            while(ThreadRun == true)
            {
                Send();
                Thread.Sleep(60);
            }
            return null;
        }
        
    }
}