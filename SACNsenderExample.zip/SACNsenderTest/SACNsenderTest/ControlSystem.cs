using System;
using System.IO;                                        // For UDP sender
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support

namespace SACNsenderTest
{
    public class ControlSystem : CrestronControlSystem
    {
        SACNSender mySender;  // Create our global container

        Thread DoRandomDmx;
        private int channel = 1;
        private bool RunThread = false;
        public ControlSystem()
            : base()
        {
            try
            {
                
                Thread.MaxNumberOfUserThreads = 20;
                
                CrestronEnvironment.ProgramStatusEventHandler += new ProgramStatusEventHandler(ControlSystem_ControllerProgramEventHandler);

            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        public override void InitializeSystem()
        {
            try
            {
                mySender = new SACNSender("192.168.8.170", 1);  // Dalek Programmer says -  INSTANTIATE!  INSTANTIATE!

                CrestronConsole.AddNewConsoleCommand(StartSacn, "startsacn", "Start the SACN data transmission stream", ConsoleAccessLevelEnum.AccessOperator);
                CrestronConsole.AddNewConsoleCommand(StopSacn, "stopsacn", "Stop transmitting the SACN data stream", ConsoleAccessLevelEnum.AccessOperator);
                CrestronConsole.AddNewConsoleCommand(RandomDMX, "dmxrand", "start/stop", ConsoleAccessLevelEnum.AccessOperator);
                CrestronConsole.AddNewConsoleCommand(null, "null", "null", ConsoleAccessLevelEnum.AccessOperator);

                CrestronConsole.PrintLine(" ###  SACN demo Program Started  ready for text console commands");

            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }
        public void StartSacn(string s)
        {
            mySender.Start();
        }
        public void StopSacn(string s)
        {
            mySender.Stop();
        }

        public void RandomDMX(string s)
        {
            if (s.Length < 2)
            {
                CrestronConsole.PrintLine(" Use: \r dmxrand [start:stop] [number from 1 to 511]");
                CrestronConsole.ConsoleCommandResponse(" Start or stop is required followed by a number.\r dmxrand start 200 will randomly change 200 address.\r dmxrand stop 0 stops the random changing thread\r");
            }
            else
            {
                string[] parts = s.Split(' ');

                CrestronConsole.ConsoleCommandResponse(" Command issued {0} random DMX on {1} channels as {2} ", parts[0], parts[1], int.Parse(parts[1]));
                channel = int.Parse(parts[1]);
                if (channel < 1 && channel > 511)
                    channel = 100;

                switch (parts[0].ToLower())
                {
                    case "start":
                        {
                            RunThread = true;
                            DoRandomDmx = new Thread(DoRandomDmxWorker, null, Thread.eThreadStartOptions.CreateSuspended);
                            DoRandomDmx.Start();
                            break;
                        }
                    case "stop":
                        {
                            RunThread = false;
                            break;
                        }
                }

            }

        }

       
        private object DoRandomDmxWorker(object o)
        {
            Random rnd = new Random();
            CrestronConsole.PrintLine("Now changing random DMX channels from 1 to {0}", channel);
            while (RunThread)
            {
                Thread.Sleep(5);
                mySender.SetRGB(rnd.Next(1,channel), (byte)rnd.Next(0,255), (byte)rnd.Next(0,255), (byte)rnd.Next(0,255));
                mySender.SetRGB(rnd.Next(1, channel), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255));
                mySender.SetRGB(rnd.Next(1, channel), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255));
                mySender.SetRGB(rnd.Next(1, channel), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255));
                mySender.SetRGB(rnd.Next(1, channel), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255), (byte)rnd.Next(0, 255));
            }

            return null;
        }
        void ControlSystem_ControllerProgramEventHandler(eProgramStatusEventType programStatusEventType)
        {
            switch (programStatusEventType)
            {
                case (eProgramStatusEventType.Stopping):
                    // Gotta kill any threads if the program is stopping.   Dont forget this.
                    mySender.Stop();
                    RunThread = false;
                    break;
            }

        }
    }
}
 