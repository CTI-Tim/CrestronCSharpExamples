﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Program
    {
        delegate void MathDelegate();

        static int result = 0;
        static void Main(string[] args)
        {
            //SetStartingValueOfTwo();

            // Assign a single method to the delegate
            MathDelegate tester = AddTwo;

            // Replace the assigned method
            tester = AddFour;

            // Invoke the delegate. ie. run the assigned method
            // tester();

            Console.WriteLine("tester result = {0}\n", result);

            // Multiple Operations
            // 2 + 3 + 4 = 9.

            // Create delegates to contain methods of interest
            MathDelegate add2 = AddTwo;
            MathDelegate add3 = AddThree;
            MathDelegate add4 = AddFour;

            // Create a Multicast Delegate (more than one method called)
            MathDelegate multicast = add2 + add3;
            multicast += add4;

            // Invoke the delegate
            multicast();

            Console.WriteLine("Multicast delegate result = {0}\n", result);

            // Order of invocation is key!
            // 2 + 2 * 4 = 10.     // not 16!
            // BEDMAS = Brackets, exponents, division, multiplication, addition, subtraction
            // Must evaluate in order --->

            // Directly adding method without assigning to delegates first
            MathDelegate BEDMAS = SetStartingValueOfTwo;
            BEDMAS += AddTwo;
            BEDMAS += TimesFour;
            // This method does not allow for the following;
            //BEDMAS = SetStartingValueOfTwo + AddTwo + TimesFour;

            // Correct the order by removing AddTwo then readding
            BEDMAS -= add2;
            BEDMAS += add2;

            // Check order of execution
            foreach (var item in BEDMAS.GetInvocationList())
            {
                Console.WriteLine("Method to execute = {0}", item.Method);
            }

            BEDMAS();

            Console.WriteLine("Result = {0}, BEDMAS = {1}!", result, result==10?"YES":"NO");

            Console.Read();
        }

        static void SetStartingValueOfTwo() { result = 2; }
        static void AddTwo() { result += 2; }
        static void AddThree() { result += 3; }
        static void AddFour() { result += 4; }
        static void TimesFour() { result *= 4; }
    }
}
