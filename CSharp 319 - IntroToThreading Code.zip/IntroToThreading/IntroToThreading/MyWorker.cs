﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading; // Dont forget to add this
using System.Threading.Tasks;

namespace IntroToThreading
{
    class MyWorker
    {
        private Thread _myThread;   // create a class level thread container
        private bool _threadRun = false;    // Semaphore to tell this thread to stop gracefully

        private Queue<string> _myQueue; // Our communication pipeline to the thread

        public MyWorker() // Default Constructor
        {
            _myThread = new Thread(ThreadCode); // setup the instance of our thread pointed at the method
            _myQueue = new Queue<string>(); // Setup the Messaging queue
        }
         ~MyWorker() //  Destructor we use this to shut the thread down if our class instance is removed
        {
            _threadRun = false;
        }

        public void Start()
        {
            _threadRun = true; // Initialize our semaphore so the thread will stay running
            _myThread.Start(); // Launch the thread
        }

        public void Stop()
        {
            _threadRun = false; // This will tell the thread to stop running
        }

        public void Send(string s)
        {
            _myQueue.Enqueue(s); // put our string in the message queue for the thread to read
        }

        private void ThreadCode()
        {
            Console.WriteLine("MyWorker Thread Code has started");

            while(_threadRun) // Loop until we tell it to stop
            {
                if(_myQueue.Count > 0) // Do we have a message sent to us?
                {
                    var Message = _myQueue.Dequeue();  // get that out of the queue
                    Console.WriteLine("MyWorker Message received = {0}",Message);
                }
            }
            Console.WriteLine("MyWorker Thread Stopped");
        }
    }
}
