﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;     //  Required to access Threading Classes
using System.Threading.Tasks;

namespace IntroToThreading
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread myThread = new Thread(Work); // Create a new Thread Instance, it will run the method "Work"
            Thread anotherThread = new Thread(Work2);  // Create a second thread

            // Use our MyWorker Class
            MyWorker WorkerThread = new MyWorker(); // create our instance of the class
            WorkerThread.Start(); // call the thread start method in our class
            WorkerThread.Send("Hello");
            WorkerThread.Send("Hola");

            myThread.Start(); // Start our thread, at this point the method we are calling is now running
            anotherThread.Start();

            Console.WriteLine("Sleeping the main program for 1 second");
            Thread.Sleep(1000);  // main thread sleeping for 1 second

            WorkerThread.Stop(); 

            Console.ReadLine();
        }

        // These are extremely basic threading examples. Still useful but very basic
        static void Work()
        {
            for (int i = 0; i <= 10; i++) // Our thread runs this loop.
            {
                Console.WriteLine("Work reports i={0}", i);
            }
            Console.WriteLine("Work ended");
        } // when we hit this point the thread will exit
        static void Work2()
        {
            for (int i = 0; i <= 10; i++) // Our thread runs this loop.
            {
                Console.WriteLine("Work2 reports i={0}", i);
            }
            Console.WriteLine("Work2 ended");
        } // when we hit this point the thread will exit
    }
}
