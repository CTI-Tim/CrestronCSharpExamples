﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Casting
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort teaspoon;    // 2 bytes
            uint teacup;        // 4 bytes
            ulong bucket;       // 8 bytes

            float coffeemug;    // 4 bytes but uses decimals - greater precision
            double bathtub;     // 8 bytes and uses decimals - greater precision

            // implicit conversion - the data will fit and no information is lost
            teaspoon = 3524;    // 5 ml of volume
            teacup = teaspoon;
            bucket = teacup;

            coffeemug = teacup;
            bathtub = coffeemug;

            Console.WriteLine("--- Implicit ---\n" +
                                "teaspoon = {0}\n" +
                                "teacup = {1}\n" +
                                "bucket = {2}\n" +
                                "coffeemug = {3}\n" +
                                "bathtub = {4}\n"
                                , teaspoon
                                , teacup
                                , bucket
                                , coffeemug
                                , bathtub);

            // explicit conversion - some precision or data may be lost
            bathtub = 65539.259256;
            coffeemug = (float)bathtub;
            teaspoon = (ushort)coffeemug;

            bucket = (ulong)coffeemug;
            teacup = (uint)bucket;
            teaspoon = (ushort)teacup;

            Console.WriteLine("--- Explicit ---\n" +
                                "bathtub = {0}\n" +
                                "coffeemug = {1}\n" +
                                "bucket = {2}\n" +
                                "coffeemug = {3}\n" +
                                "teaspoon = {4}\n"
                                , bathtub
                                , coffeemug
                                , bucket
                                , teacup
                                , teaspoon);


            // String conversion

            string chain = "abcd";
            char link = 'e';

            chain += link; // implicit

            Console.WriteLine("Total chain = {0}", chain);


            // Helper Classes - Convert

            int z = Convert.ToInt32("12345");

            Console.WriteLine("AtoI Operation = {0}", z);


            // Built-in methods

            int a, b;
            int.TryParse("12$4", out a);       // will return 0 due to $
            int.TryParse("789", out b);

            Console.WriteLine("TryParse Operation: a = {0}, b = {1}", a, b);




            Console.Read();
        }
    }
}
