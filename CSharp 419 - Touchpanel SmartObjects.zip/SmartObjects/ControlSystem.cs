using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.UI;
using Crestron.SimplSharp.CrestronIO;
using System.Collections.Generic;

namespace SmartObjects
{
    public class ControlSystem : CrestronControlSystem
    {
        XpanelForSmartGraphics myPanel;

        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                myPanel = new XpanelForSmartGraphics(0x82, this);
                // Used for Digital, Analog and Serial Join numbers
                // Not used for SmartObject sig changes
                // myPanel.SigChange += MyPanel_SigChange;

                string SGDFilePath = Path.Combine(Directory.GetApplicationDirectory(), "SmartGraphicsProject.sgd");

                if (myPanel.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                {
                    ErrorLog.Error("Failure in myPanel registration = {0}", myPanel.RegistrationFailureReason);
                }
                else
                {
                    if (File.Exists(SGDFilePath))
                    {
                        // Load the SGD File into the panel definition
                        myPanel.LoadSmartObjects(SGDFilePath);

                        foreach (KeyValuePair<uint, SmartObject> pair in myPanel.SmartObjects)
                        {
                            pair.Value.SigChange += MySmartObjectSigChange;
                        }
                    }
                    else
                    {
                        ErrorLog.Error("SmartGraphics Definition file not found! Set .sgd file to 'Copy Always'!");
                    }
                
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        private void MySmartObjectSigChange(GenericBase currentDevice, SmartObjectEventArgs args)
        {
            CrestronConsole.PrintLine("SmartObject that was used = ID {0}", args.SmartObjectArgs.ID);
            
            switch ((PanelSmartObjectIDs)args.SmartObjectArgs.ID)
            {
                case PanelSmartObjectIDs.myDPad:
                    {
                        // First off, check what the incoming arguments will provide per button press;
                        CrestronConsole.PrintLine("myDPad button pressed;" +
                            "signal = {0}, number = {1}, name = {2}",
                            args.Sig.GetType(),
                            args.Sig.Number,
                            args.Sig.Name);

                        // Then apply logic to trigger actions based on the press
                        switch (args.Sig.Name)
                        {
                            case ("Up"):
                            case ("Down"):
                            case ("Left"):
                            case ("Right"):
                            case ("Center"):
                                {
                                    myPanel.StringInput[1].StringValue = args.Sig.Name;
                                    break;
                                }
                            default:
                                break;
                        }

                        break;
                    }
                case PanelSmartObjectIDs.myBLV:
                    {
                        // First off, check what the incoming arguments will provide per button press;
                        CrestronConsole.PrintLine("myBLV button pressed;" +
                            "signal = {0}, number = {1}, name = {2}",
                            args.Sig.GetType(),
                            args.Sig.Number,
                            args.Sig.Name);

                        // Use the cue name to select the appropriate signal
                        ushort itemClicked = args.SmartObjectArgs.UShortOutput["Item Clicked"].UShortValue;

                        myPanel.StringInput[1].StringValue = string.Format("List Button {0}", itemClicked);

                        break;
                    }
                case PanelSmartObjectIDs.myRefList:
                    {
                        // First off, check what the incoming arguments will provide per button press;
                        CrestronConsole.PrintLine("myRefList button pressed;" +
                            "signal = {0}, number = {1}, name = {2}",
                            args.Sig.GetType(),
                            args.Sig.Number,
                            args.Sig.Name);

                        // PSEUDOCODE;
                        // On a rising edge of a digital press only!
                        // Determine which subpage instance was pressed
                        // Determine which of the three presets were selected
                        // Send the value to the gauge on the correct subpage (cue name is "an_fb#")

                        if (args.Sig.Name.Contains("press") && args.Sig.BoolValue == true)
                        {
                            // First press is number 4011
                            double number = args.Sig.Number - 4010;

                            // Subpage #
                            double instance = Math.Ceiling(number / 3);

                            // Preset Pressed
                            double preset = number - (instance - 1) * 3;

                            // Generate the analog fb cue name
                            string aCue = string.Format("an_fb{0}", instance);

                            // Fill the gauge
                            myPanel.SmartObjects[(uint)PanelSmartObjectIDs.myRefList].UShortInput[aCue].UShortValue = PresetValue(preset);

                            myPanel.StringInput[1].StringValue = string.Format("SPRL {0}", args.Sig.Name);
                        }

                        break;
                    }
                default:
                    break;
            }

        }

        ushort PresetValue(double presetChosen)
        {
            float presetLevel;
            switch (presetChosen)
            {
                case 1: { presetLevel = 15; break; }
                case 2: { presetLevel = 50; break; }
                case 3: { presetLevel = 85; break; }
                default: { presetLevel = 0; break; }
            }

            // Helpful methods within the DeviceSupport namespace
            return SimplSharpDeviceHelper.PercentToUshort(presetLevel);

        }

        public enum PanelSmartObjectIDs
        { 
            myDPad = 1,
            myBLV = 2,
            myRefList = 3
        }
    }
}