﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccessModifiersLibrary;

namespace AccessModifiers
{
    class Program
    {
        static void Main(string[] args)
        {
            // instantiation of a private class in the same namespace
            // TestAccess tac = new TestAccess();
            // fails when class is static

            // accessing a public method in the class object
            // tac.MethodToGet();
            // fails when method is static

            // accessing a static method without instantiation
            // also, syntax for accessing a static class
            TestAccess.MethodToGet();

            // Static Math class
            double x = Math.Pow(5, 6);

            // public class in another library
            // LibraryClass myLib = new LibraryClass();
            // fails when class is static

            // not even an option when the class is internal
            // LibraryClass

            // public method accessed through object of class
            // myLib.LibraryMethod(8);
            // fails when method is static

            // static public method accessed directly
            // LibraryClass.LibraryMethod(8);
            // fails when method is internal

            OtherLibraryClass olc = new OtherLibraryClass();

            // indirect access to internal LibraryMethod
            olc.AccessInternal(10);
        }
    }

    static class TestAccess
    {
        static public void MethodToGet() { }
    }
}
