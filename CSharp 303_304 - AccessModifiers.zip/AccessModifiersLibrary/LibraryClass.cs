﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModifiersLibrary
{
    static internal class LibraryClass
    {
        static int x;
        static internal void LibraryMethod(int incoming)
        {
            x = incoming;
        }
    }

    public class OtherLibraryClass : ProtectedData
    {
        public void AccessInternal(int incoming)
        {
            LibraryClass.LibraryMethod(incoming);
            // LibraryClass lc = new LibraryClass();
            // lc.LibraryMethod(incoming);
        }

        public void AccessProtected()
        {
            ProtectedData pd = new ProtectedData();
            //pd.z // no access to z
            OtherLibraryClass olc = new OtherLibraryClass();
            olc.z = 32; // direct access to z
        }
    }

    public class ProtectedData
    {
        protected int z = 5; // can be used in this class
    }
}
