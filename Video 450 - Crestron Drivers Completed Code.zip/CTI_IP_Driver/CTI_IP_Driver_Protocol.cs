﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crestron.SimplSharp;
using Crestron.RAD.DeviceTypes.Display;
using Crestron.RAD.Common.Transports;
using Crestron.RAD.Common.BasicDriver;
using Crestron.RAD.Common.Enums;

namespace CTI_IP_Driver
{
    // Connects our protocol to the framework protocol
    public class CTI_IP_Driver_Protocol : ADisplayProtocol
    {
        const string outHeader = "\x02\x01\x00\x00";
        const string outDelim = "\x00\x00\x00\x03";

        const string _powerOnResponse = "PON";
        const string _powerOffResponse = "POF";
        const string _warmingUpResponse = "WRM";
        const string _coolDownResponse = "COL";

        public CTI_IP_Driver_Protocol(ISerialTransport transportDriver, byte id) : base(transportDriver, id)
        {
            ResponseValidation = new ResponseValidator(ValidatedData);

            ValidatedData.PowerOnPollingSequence = new[]
            { 
                StandardCommandsEnum.LampHoursPoll
            };
        }

        protected override bool PrepareStringThenSend(CommandSet commandSet)
        {
            CrestronConsole.PrintLine("@@@@@[DRIVER] commandSetGroup = {0}, commandSetCommand = {1}",
                commandSet.CommandGroup, commandSet.Command);

            // Assemble the outgoing command combining headers, delims, the command from the JSON file
            // or any additional operations. ie. checksums

            commandSet.Command = string.Format("{0}{1}{2}", outHeader, commandSet.Command, outDelim);
            commandSet.CommandPrepared = true;

            return base.PrepareStringThenSend(commandSet);
        }

        protected override void DeConstructPower(string response)
        {
            CrestronConsole.PrintLine("@@@@@[DRIVER] Deconstructing Power. Response = {0}", response);
            string _response = "";

            switch (response)
            {
                case _powerOnResponse:
                    WarmedUp(this);
                    _response = ValidatedData.PowerFeedback.Feedback[StandardFeedback.PowerStatesFeedback.On];
                    break;
                case _powerOffResponse:
                    CooledDown(this);
                    _response = ValidatedData.PowerFeedback.Feedback[StandardFeedback.PowerStatesFeedback.Off];
                    break;
                case _warmingUpResponse:
                    WarmUp();
                    _response = ValidatedData.PowerFeedback.Feedback[StandardFeedback.PowerStatesFeedback.On];
                    break;
                case _coolDownResponse:
                    CoolDown();
                    _response = ValidatedData.PowerFeedback.Feedback[StandardFeedback.PowerStatesFeedback.On];
                    break;
                default:
                    break;
            }

            base.DeConstructPower(_response);
        }

        protected override void DeConstructLampHours(string response)
        {
            string sTemp = response.Replace(ValidatedData.LampHourFeedback.GroupHeader, "");

            CrestronConsole.PrintLine("@@@@@[DRIVER] DeconstructLampHours. Base call data = {0}.", sTemp);

            base.DeConstructLampHours(sTemp);
        }

        protected override void ChooseDeconstructMethod(ValidatedRxData validatedData)
        {
            // 'validatedData' is returned here first
            // Customize deconstruct calls or perform custom processing

            if (validatedData.CustomCommandGroup == "PollResponse")
            {
                string incoming = validatedData.Data;
                int lHIndex = incoming.IndexOf("LH?");
                string lTemp = incoming.Substring(lHIndex, incoming.IndexOf("NR?") - 1 - lHIndex);

                incoming = incoming.Replace(lTemp, "");

                // With lamp hours response removed, the data can now be processed.
                // Here we are sending our remaining data to the log, but could send elsewhere for processing.
                Log(string.Format("&&&&&[LOG] Remaining data = {0}", incoming));

                // Then call the lamp hours deconstruct method
                DeConstructLampHours(lTemp);
            }
            else    // If the response is not one of our custom responses then allow the Framework to choose
            {
                Log("&&&&&[LOG] Let the framework decide the deconstruct");
                base.ChooseDeconstructMethod(validatedData);
            }
        }
    }

    // Allows handling of returned responses
    public class ResponseValidator : ResponseValidation
    {
        public ResponseValidator(DataValidation dataValidation) : base(dataValidation)
        {

        }

        public override ValidatedRxData ValidateResponse(string response, CommonCommandGroupType commandGroup)
        {
            const string inHeader = "\x02";
            const string inDelim = "\x03";

            string rTemp = response;

            ValidatedRxData validatedData = new ValidatedRxData(false, string.Empty);

            CrestronConsole.PrintLine("@@@@@[DRIVER] ValidateResponse. Response = {0}, commandGroup = {1}",
                response.ToString(), commandGroup.ToString());

            if (!rTemp.StartsWith(inHeader) || !rTemp.EndsWith(inDelim))
            {
                // Should the incoming data not be complete, return a base call to continue gathering responses
                return base.ValidateResponse(response, commandGroup);
            }
            if (rTemp.Contains(DataValidation.LampHourFeedback.GroupHeader))
            {
                commandGroup = CommonCommandGroupType.LampHours;

                if (rTemp.Contains("ERR"))
                {
                    // This is a reponse to the 'POL' command. 3 sets of data were returned

                    // Example;
                    // ERR\x01LH?1234NR?\x19\x20x\x10\x80   (header and footer bytes already removed)

                    // Choose a custom commandgroup
                    commandGroup = CommonCommandGroupType.Other;
                    validatedData.CustomCommandGroup = "PollResponse";
                }
            }

            rTemp = rTemp.Replace(inHeader, "");
            rTemp = rTemp.Replace(inDelim, "");

            validatedData.CommandGroup = commandGroup;
            validatedData.Data = rTemp;
            validatedData.Ready = true;
            return validatedData;
        }
    }
}