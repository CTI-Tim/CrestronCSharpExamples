﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crestron.SimplSharp;
using Crestron.RAD.DeviceTypes.Display; // Select from currently supported device types to access the abstract device class
using Crestron.RAD.Common.Interfaces;   // Allows selection of communication interface
using Crestron.RAD.Common.Transports;   // Required to expose TCP comms
using Crestron.RAD.Common.BasicDriver;  // Common logic for all device types

namespace CTI_IP_Driver
{
    public class CTI_IP_Driver_Transport : ABasicVideoDisplay, ITcp
    {

        public CTI_IP_Driver_Transport()
        { }

        // Will pass our communication settings to the framework and allow protocol initialization (deserialize the JSON)
        public void Initialize(IPAddress ipAddress, int port)
        {
            InternalEnableLogging = true;

            // This is the carrier for the connection information and handler for establishing comms
            var tcpTransport = new TcpTransport
            {
                EnableAutoReconnect = EnableAutoReconnect,
                EnableLogging = InternalEnableLogging,
                CustomLogger = InternalCustomLogger,
                EnableRxDebug = InternalEnableRxDebug,
                EnableTxDebug = InternalEnableTxDebug
            };

            tcpTransport.Initialize(ipAddress, port);
            ConnectionTransport = tcpTransport;     // Satisfies a component of ABasicDriver

            DisplayProtocol = new CTI_IP_Driver_Protocol(ConnectionTransport, Id)
            {
                EnableLogging = InternalEnableLogging,
                CustomLogger = InternalCustomLogger
            };
            
            // Makes incoming message visible in SIMPL
            EnableRxOut = true;

            DisplayProtocol.StateChange += StateChange;
            DisplayProtocol.RxOut += DisplayProtocol_RxOut;
            DisplayProtocol.Initialize(DisplayData);
            // 'DisplayData' is the JSON RootObject from deserialization of the driver JSON file
        }

        private void DisplayProtocol_RxOut(string message)
        {
            CrestronConsole.PrintLine("@@@@@[DRIVER] Message incoming from device = {0}", message);
            SendRxOut(message);
        }
    }
}