﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjLampHours
{
    class Program
    {
        static void Main(string[] args)
        {
            Projector TrainingRoom1 = new Projector("Training Room1 Sony Projector"); 

            Console.WriteLine("Type 'get' to get lamp hours and anything else to exit");    //Ask user to type 
            string userInput = "get";                                                       //take user input

            while (userInput.Equals("get"))
            {
                Console.Write("User Input: ");
                userInput = Console.ReadLine();
                if (userInput != "get")
                {
                    return;
                }
                Console.WriteLine("Lamp Hours = {0}", TrainingRoom1.LampHours());
            }

        }
    }
}
