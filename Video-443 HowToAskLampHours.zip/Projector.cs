﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjLampHours
{
    class Projector
    {
        private bool _powerState;                     // variable  _powerState  
        private int _lampHours;						  // variable  _lampHours  
        Random random = new Random();                 // Instantiate random number generator using system-supplied value as seed. 
        public string Name { get; private set; }      // variable for string prorperty Name and get and set methods
        public bool PowerStatus                      // boolean keyword  bool to see power status
        {
            get
            {
                return _powerState;                 //return power state using get accesor method
            }
        }

        /// <summary>
        /// Projector name is required for instantiation
        /// </summary>
        /// <param name="name"></param>
        public Projector(string name)              //pass string  name to Projector
        {
            Name = name;                          // assing name to variable Name
        }

        /// <summary>
        /// Method to Power On Projector
        /// </summary>
        public void PowerOn()
        {
            ProjectorCommand("PON");
            _powerState = true;
        }

        /// <summary>
        /// Method to Power Off Projector
        /// </summary>
        public void PowerOff()
        {
            ProjectorCommand("POF");
            _powerState = false;
        }

        //Lamp Hours Method
        public int LampHours()
        {
            // Command if you were to send in Simpl Windows = \xC0\x00\x37\x00\xF7
            ProjectorCommand("0xC00x000x370x000xF7");

            // Calls LampHoursFeedback for fake emulation
            LampHoursFeedback("");

            return _lampHours;
        }

        private void ProjectorCommand(string commandToSendToProjector)
        {
            // This will be the network sockets implementation to send command to projector via TCP/IP

            // when we get lamp hours feedback from projector, then we update the method for LampHoursFeedback(string projectorRxFeedback)
        }

        /// <summary>
        /// Method to parse projectorRxFeedback to get actual lamp hours
        /// It may require bit shifting or some other math operations
        /// </summary>
        /// <param name="projectorRxFeedback"></param>
        private void LampHoursFeedback(string projectorRxFeedback)
        {
            // below is emulating fake lamp hours
            if (_lampHours <= 20000)
            {
                _lampHours += random.Next(10, 8000);
            }

            if (_lampHours >= 20000)
            {
                Console.WriteLine("{0} Max Lamp Hours Reached, service required!!!!", Name);
            }
        }
    }
}

