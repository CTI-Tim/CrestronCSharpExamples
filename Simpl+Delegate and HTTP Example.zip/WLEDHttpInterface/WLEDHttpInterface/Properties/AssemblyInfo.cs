﻿using System.Reflection;

[assembly: AssemblyTitle("WLEDHttpInterface")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("WLEDHttpInterface")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyVersion("1.0.0.*")]

