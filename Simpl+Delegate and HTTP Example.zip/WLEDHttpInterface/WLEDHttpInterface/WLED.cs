﻿using System;
using System.Text;
using Crestron.SimplSharp.CrestronIO;
using Crestron.SimplSharp;                  // For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;         // Let's  get Http access



/*  NOTE :  THIS IS FOR EDUCATIONAL USE ONLY.  DO NOT USE IN PRODUCTION. THIS CODE IS UNSUPPORTED
 *   
 *  Written by Tim Gray Sr Techical Trainer, Masters C# Instructor at Crestron.
 *  
 *  This Library is written for use in Simpl Plus as an example only.  It has no guarentees it will work or stay working.
 *  Use it at your own risk.  Crestron will not support this code, do not call tech support over this code.
 *  It uses Integers for sending bool states like on and off because S+ can not handle bool
 *  There is a seperate version that is for use in C#  It is called WledHttpInterfaceCSharp
 *  You could use this one in your C# code but it would be messy due to the lack of bools
 *  Note: This is also written in a clear manner to allow those new to C# programming for Crestron
 *  to understand it easier.   
 *   
 *  What is WLED?   it is a DIY addressable LED codebase firmware for ESP32 and ESP8266 based designs that 
 *  simplifies control of addressable LED systems in a open source way.
 *  You can find out more about this at https://kno.wled.ge/.  
 *  
 * 
 *  NOTE :  THIS IS FOR EDUCATIONAL USE ONLY.  DO NOT USE IN PRODUCTION. THIS CODE IS UNSUPPORTED
 */


namespace WLEDHttpInterface
{
    public delegate void myDelegate(ushort Value); //Simpl Plus requires the delegate to have some kind of parameter, we are not going to use it.

    public class WLED
    {
        private ushort _brightness;

        // Properties  all are private setters
        public ushort Brightness
        {
            get
            {
                return _brightness;
            }
            private set
            {
                _brightness = value;

                if (value > 0)
                {
                    State = 1;
                }
                else
                {
                    State = 0;
                }
            }
        }
        public ushort NightLight { get; private set; }
        public ushort Preset { get; private set; }
        public string Name { get; private set; }
        public ushort State { get; private set; }
        // Except this one.  we need a way to set the address we will connect to
        public string Address { get; set; }

        // I would prefer to use the default constructor,  but Simpl+ does not allow passing parameters on instantiation.

        //Delegates
        public myDelegate WledDelegate { get; set; }    // This is where we create our copy of the delegate in our class.
                                                        // In Simpl+ you will use this copy, not the origional. 

        public void On()
        {
            SendCommand("T=1");
        }
        public void Off()
        {
            SendCommand("T=0");
        }
        public void SetPreset(ushort PresetNumber)
        {
            if(PresetNumber > 0 && PresetNumber < 17)           // WLED only supports 16 presets 1-16
                SendCommand("PL=" + PresetNumber.ToString());
        }
        public void SetBrightness(ushort BrightnessLevel)
        {
            if( BrightnessLevel >= 0 && BrightnessLevel < 256)   // Valid brightness is 0 to 255 0 will turn it off
                SendCommand("A=" + BrightnessLevel.ToString());
        }
        public void Poll()
        {
            SendCommand(""); // send a polling command
        }

        // Private Methods

        private void SendCommand(string Command)
        {
            var result = "";
            if (Command.Length > 0)
                result = Connect( "&" + Command);
            else
                result = Connect("");

            Parse(result);
            WledDelegate(1); //  delegate trigger so we can run S+ code when anything updates the 1 does not matter, we could send a 0 or anything to 65535
        }
        private string Connect(string Command)
        {
            string result = "err";
            string Url = "http://" + Address + "/win" + Command;  // assemble the URL
            
            var client = new HttpClient();
            client.KeepAlive = false;
            var request = new HttpClientRequest();

            request.Url.Parse(Url);
            request.ContentString = "";
            request.RequestType = RequestType.Get;
            
            HttpClientResponse response = client.Dispatch(request);
            result = response.ContentString;
            // NOTE:  if you look at a string in Debugger that is sent from C# it will truncate. look at it in console.
            //CrestronConsole.PrintLine(result);
            response.Dispose();
            client.Dispose();
            return result;
        }
        private void Parse(string Payload)
        {
            // we could go all fancy using an XML parser, but why when we only need to grab a small number of things easily
            Brightness = ushort.Parse(TagFinder(Payload,"ac"));
            Preset = ushort.Parse(TagFinder(Payload,"ps"));
            Name = TagFinder(Payload,"ds");
        }
        private string TagFinder(string Payload, string Key)
        {
            // This brute force XML data extractor only works on things that are between tags.
            // Why load an 11K library to grab a couple of things.
            var p1 = Payload.IndexOf("<"+Key+">");
            var p2 = Payload.IndexOf("</"+Key+">");
            return Payload.Substring(p1 + 2 + Key.Length, p2 - p1 - (Key.Length + 2));
        }
    }
}
