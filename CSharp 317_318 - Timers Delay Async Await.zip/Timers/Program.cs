﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Timers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 'start' to wait for 3 seconds:");
            string input = Console.ReadLine().ToLower();

            if (input.Equals("start"))
            {
                Console.WriteLine("{0} - Starting the 3 second test...", DateTime.Now);

                // **** Sleep ****
                // Blocking call - causes this thread to pause execution
                // Nothing else can happen in the main thread during this operation
                Thread.Sleep(3000);
                Console.WriteLine("{0} - 3 second sleep is completed.\n", DateTime.Now);

                // **** Timer ****
                // Full name used as it would conflict with System.Threading.Timer
                System.Timers.Timer sysTimer = new System.Timers.Timer();
                sysTimer.Interval = 3000;
                sysTimer.AutoReset = false;             // only run one time
                sysTimer.Elapsed += SysTimer_Elapsed;

                Console.WriteLine("{0} - Starting sysTimer!\n", DateTime.Now);
                // This is a non-blocking call - uses another thread for execution
                sysTimer.Start();
                Console.WriteLine("Main thread keeps executing as the sysTimer is counting.\n");

                // Start a 5 second sleep on the main thread
                Thread.Sleep(5000);
                Console.WriteLine("Five second sleep is done!\n");

                // Synchronous operation
                // ie. we get out answer right away!
                double x = Math.Sqrt(25);

                // **** Delay ****
                // Non-blocking call - uses another thread for execution
                // Asynchronous operation based on whatever 'await' is doing
                Console.WriteLine("{0} - Pre 3-second delay.\n", DateTime.Now);

                var myTask = Task.Run( async () => 
                {
                    await Task.Delay(3000);
                    DelayOutput();
                });
                Console.WriteLine("{0} - Just after Task.Run.\n", DateTime.Now);

                myTask.Wait();
                Console.WriteLine("{0} - This only happens once the Task is completed.", DateTime.Now);

            }
            string x = "".ToString();
            Console.Read();
        }

        private static void DelayOutput()
        {
            Console.WriteLine("{0} - Post 3-second delay.", DateTime.Now);
        }

        private static void SysTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            Console.WriteLine("{0} - sysTimer has completed!", DateTime.Now);
        }
    }
}

