using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;             // For Generic Device Support
using Crestron.SimplSharpPro.Keypads;                   // For Keypad support

namespace RelaysVideo421
{
    public class ControlSystem : CrestronControlSystem //Constructor Entery point of to program
    {
        /// <summary>
        /// ControlSystem Constructor. Starting point for the SIMPL#Pro program.
        /// Use the constructor to:
        /// * Initialize the maximum number of threads (max = 400)
        /// * Register devices
        /// * Register event handlers
        /// * Add Console Commands


        private C2nCbfP myKeypad;    //declaring a variable to access myKeypad class


        /// Please be aware that the constructor needs to exit quickly; if it doesn't
        /// exit in time, the SIMPL#Pro program will exit.
        ///
        /// You cannot send / receive data in the constructor
        /// </summary>
        public ControlSystem() //Constructor
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                //Subscribe to the controller events (System, Program, and Ethernet)
                CrestronEnvironment.SystemEventHandler += new SystemEventHandler(ControlSystem_ControllerSystemEventHandler);
                CrestronEnvironment.ProgramStatusEventHandler += new ProgramStatusEventHandler(ControlSystem_ControllerProgramEventHandler);
                CrestronEnvironment.EthernetEventHandler += new EthernetEventHandler(ControlSystem_ControllerEthernetEventHandler);

                #region Relay   
                if (this.SupportsRelay) //check to see if it supports Relay
                {
                    //Register just the relay number 1

                    if (this.RelayPorts[1].Register() != eDeviceRegistrationUnRegistrationResponse.Success) //check to see if the Relay Registration 
                        ErrorLog.Error("Error Registering Relay {0}: {1}", 1, this.RelayPorts[1].DeviceRegistrationFailureReason);
                    this.RelayPorts[1].StateChange += new RelayEventHandler(ControlSystem_RelayChange);


                    //Register just the relay number 2
                    if (this.RelayPorts[2].Register() != eDeviceRegistrationUnRegistrationResponse.Success)  //Check to see if the Relay Registration is not registred.
                        ErrorLog.Error("Error Registering Relay {0}: {1}", 2, this.RelayPorts[2].DeviceRegistrationFailureReason);
                    this.RelayPorts[2].StateChange += new RelayEventHandler(ControlSystem_RelayChange);
                }
                #endregion

                #region Keypad
                if (this.SupportsCresnet) //check to see if it supports cresnet
                {
                    //Register keypad at cresnet ID 30

                    myKeypad = new C2nCbfP(0x30, this);
                    myKeypad.ButtonStateChange += new ButtonEventHandler(myKeypad_ButtonStateChange); //every button change will add to event handler
                    if (myKeypad.Register() != eDeviceRegistrationUnRegistrationResponse.Success)// check if the registration is not successfull, then add to error log
                        ErrorLog.Error("Error Registering Keypad on ID: 0x30: {0}", myKeypad.RegistrationFailureReason);
                }
                #endregion


            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        /// <summary>
        /// InitializeSystem - this method gets called after the constructor
        /// has finished.
        ///
        /// Use InitializeSystem to:
        /// * Start threads
        /// * Configure ports, such as serial and verisports
        /// * Start and initialize socket connections
        /// Send initial device configurations
        ///
        /// Please be aware that InitializeSystem needs to exit quickly also;
        /// if it doesn't exit in time, the SIMPL#Pro program will exit.
        /// </summary>
        public override void InitializeSystem()
        {
            try
            {
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        //Keypad Events for Button Actions
        void myKeypad_ButtonStateChange(GenericBase device, ButtonEventArgs args) //each button actions are handled below
        {
            switch (args.Button.Number)
            {
                case 1: //Labeled as Prepare
                    if (args.Button.State == eButtonState.Pressed)
                        this.RelayPorts[1].Close();
                    else
                        this.RelayPorts[1].Open();
                    break;//get  out of the case 1
                case 2: //Labelled as Entertain
                    if (args.Button.State == eButtonState.Pressed)
                        this.RelayPorts[2].State = !this.RelayPorts[2].State; //This is the Toggle State behaviour with ! Not'ed
                    break;
                default:
                    break;

            }
            /*
             *  button 1 to be a momentary presson relay #1 with feedback 
             *  button 2 is toggle on relay #2 with feedback
             */
        }

        void ControlSystem_RelayChange(Relay relay, RelayEventArgs args) //All the changes in the relay actions handled here
        {
            switch (relay.ID)
            {
                case 1:  //check change in relay #1
                    if (this.RelayPorts[1].State == true) //if relay #1 is true or closed
                        myKeypad.Feedbacks[1].State = true; //then set button #1 feedback to be true / LED on
                    else //if relay #1 is NOT true or closed
                        myKeypad.Feedbacks[1].State = false; //then set button #1 feedback to be false / LED Off
                    break;
                case 2: //check change in relay #2
                    myKeypad.Feedbacks[2].State = this.RelayPorts[2].State; //always set button #2 feedback to be the state of relay #2 
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Event Handler for Ethernet events: Link Up and Link Down.
        /// Use these events to close / re-open sockets, etc.
        /// </summary>
        /// <param name="ethernetEventArgs">This parameter holds the values
        /// such as whether it's a Link Up or Link Down event. It will also indicate
        /// wich Ethernet adapter this event belongs to.
        /// </param>
        void ControlSystem_ControllerEthernetEventHandler(EthernetEventArgs ethernetEventArgs)
        {
            switch (ethernetEventArgs.EthernetEventType)
            {//Determine the event type Link Up or Link Down
                case (eEthernetEventType.LinkDown):
                    //Next need to determine which adapter the event is for.
                    //LAN is the adapter is the port connected to external networks.
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {
                        //
                    }
                    break;
                case (eEthernetEventType.LinkUp):
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {

                    }
                    break;
            }
        }

        /// <summary>
        /// Event Handler for Programmatic events: Stop, Pause, Resume.
        /// Use this event to clean up when a program is stopping, pausing, and resuming.
        /// This event only applies to this SIMPL#Pro program, it doesn't receive events
        /// for other programs stopping
        /// </summary>
        /// <param name="programStatusEventType"></param>
        void ControlSystem_ControllerProgramEventHandler(eProgramStatusEventType programStatusEventType)
        {
            switch (programStatusEventType)
            {
                case (eProgramStatusEventType.Paused):
                    //The program has been paused.  Pause all user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Resumed):
                    //The program has been resumed. Resume all the user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Stopping):
                    //The program has been stopped.
                    //Close all threads.
                    //Shutdown all Client/Servers in the system.
                    //General cleanup.
                    //Unsubscribe to all System Monitor events
                    break;
            }

        }

        /// <summary>
        /// Event Handler for system events, Disk Inserted/Ejected, and Reboot
        /// Use this event to clean up when someone types in reboot, or when your SD /USB
        /// removable media is ejected / re-inserted.
        /// </summary>
        /// <param name="systemEventType"></param>
        void ControlSystem_ControllerSystemEventHandler(eSystemEventType systemEventType)
        {
            switch (systemEventType)
            {
                case (eSystemEventType.DiskInserted):
                    //Removable media was detected on the system
                    break;
                case (eSystemEventType.DiskRemoved):
                    //Removable media was detached from the system
                    break;
                case (eSystemEventType.Rebooting):
                    //The system is rebooting.
                    //Very limited time to preform clean up and save any settings to disk.
                    break;
            }

        }
    }
}
//MyFirstCrestronProgram
