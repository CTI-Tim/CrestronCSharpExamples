﻿using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.UI;
using System;

namespace TouchpanelsInaList
{
    public class Touchpanel
    {
        // Containers
        ControlSystem cs;           // This is generic enough
        Tsw760 myTp;                //  This is specific making this only target a specific panel  Is there a more generic class we can use?     
        // Event
        public event EventHandler<TouchPanelEventArgs> SigChange;
        //Properties
        public bool Online { get; private set; }
        public uint IpId { get; private set; }



        // Default constructor
        public Touchpanel(ControlSystem controlSystem, uint ipid)
        {
            this.cs = controlSystem;
            this.IpId = ipid;

            myTp = new Tsw760(ipid, cs);
            if (myTp.Register() == eDeviceRegistrationUnRegistrationResponse.Success)
            {
                myTp.SigChange += MyTp_SigChange;
                myTp.OnlineStatusChange += MyTp_OnlineStatusChange;
            }
            else
                CrestronConsole.PrintLine("Could not register TP at IPID 0x{0:X}", ipid);
        }

        // We are simply setting a property to indicate if the specific panel is on line.
        // No events are triggered outside of this class,  IF you need the on line event you can create and add
        // to this class another event to pass that information along.
        private void MyTp_OnlineStatusChange(GenericBase currentDevice, OnlineOfflineEventArgs args)
        {
            if (args.DeviceOnLine)
                Online = true;
            else
                Online = false;
        }

        // We create the methods to send the Digitals, Analogs and Serials.   This Class will not support smart objects
        // but it would not be too hard to add in smart object handling.  Just remember to be generic enough when you add it
        // by passing the smart object ID and the smart object join name.  You would also have to add in another event handler
        // to manage the smart object events.

        public void SetDigital(uint join, bool value)
        {
            myTp.BooleanInput[join].BoolValue = value;
        }
        public void SetAnalog(uint join, ushort value)
        {
            myTp.UShortInput[join].UShortValue = value;
        }
        public void SetString(uint join, string value)
        {
            myTp.StringInput[join].StringValue = value;
        }




        private void MyTp_SigChange(BasicTriList currentDevice, SigEventArgs args)
        {
            OnSigChangeEvent(new TouchPanelEventArgs(currentDevice, args));
        }

        protected virtual void OnSigChangeEvent(TouchPanelEventArgs e)
        {
            EventHandler<TouchPanelEventArgs> raiseEvent = SigChange;   // Make a copy
            if (raiseEvent != null)                                      // Make sure we have subscribers
            {
                raiseEvent(this, e);
            }
        }
    }

    //  This is the event args and all we are doing is passing along the data from the touch panel event handler.
    //  Effectively wrapping  the data into a new event.  This is only for sending the raw event data back out.
    //  Typically you should handle your work for the touch panel inside here and then send out events that
    //  matter to the control system and your code
    public class TouchPanelEventArgs : EventArgs
    {
        public BasicTriList currentDevice;
        public SigEventArgs args;
        public TouchPanelEventArgs(BasicTriList currentDevice, SigEventArgs args)
        {
            this.currentDevice = currentDevice;
            this.args = args;
        }
    }
}
