using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using System;
using System.Collections.Generic;

/*
 * This example shows you how to use a class with your touch panels and put them into a list as well as creating a simple delegate that 
 * can be used to update all of the touch panels at once.
 * 
 * This can be very useful for dynamic programming.   In this example we are simply using a for loop,  but you could 
 * have the touch panels defined in a configuration file and on start load that config file and create
 * all of the touch panels in your system.   
 * 
 * This is a very basic example and has no sanity checking, error checking, or anything to recover from errors.
 * It is up to the student to add in that code to make the program more stable and robust for production code.
 * This is for example purposes only,  do not call True Blue support for help with this code.
 */



namespace TouchpanelsInaList
{
    public class ControlSystem : CrestronControlSystem
    {
        // Globals Go Here
        List<Touchpanel> myTouchpanels = new List<Touchpanel>();            // create our touch panel list


        // Lets create a delegate to change a digital on all
        // touch panels at the same time.
        private delegate void OnlineDelegate(uint join, bool value);        // Notice this looks exactly like the SetDigital method?
        OnlineDelegate dOnline;                                             // And create an instance of that delegate

        public ControlSystem()
            : base()
        {
            // This is only for things that need to be setup.
            // NO ACCESS to hardware or Threading here
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }


        public override void InitializeSystem()
        {

            try
            {
                // Lets create 7 touch panels from id 03 to id 09
                for (int i = 3; i < 10; i++)
                {
                    CrestronConsole.PrintLine("Creating touch panel number {0:X}", i);
                    myTouchpanels.Add(new Touchpanel(this, (uint)i));
                    CrestronConsole.PrintLine("Subscribing touch panel number {0:X} at index number{1}", i, i - 3);
                    myTouchpanels[i - 3].SigChange += Touchpanel_SigChange; // Why -3?  because the ID number and index are not the same

                    dOnline += myTouchpanels[i - 3].SetDigital; // Subscribe the SetDigital method of all touch panels to the delegate.

                }
            }
            catch (Exception e)
            {
                CrestronConsole.PrintLine(e.Message);
            }
        }

        private void Touchpanel_SigChange(object sender, TouchPanelEventArgs e)
        {
            CrestronConsole.PrintLine("Event from IPID {0:X}", e.currentDevice.ID);
            CrestronConsole.Print("Signal Type {0}", e.args.Sig.Type.ToString());
            switch (e.args.Sig.Type)
            {
                case eSigType.String:
                    CrestronConsole.PrintLine(" Value = {0}", e.args.Sig.StringValue);
                    break;
                case eSigType.Bool:
                    CrestronConsole.PrintLine(" Value = {0}", e.args.Sig.BoolValue);
                    if (e.args.Sig.Number == 1)
                    {
                        dOnline(e.currentDevice.ID, e.args.Sig.BoolValue);   // Send the state to all panels
                    }
                    break;
                case eSigType.UShort:
                    CrestronConsole.PrintLine(" Value = {0}", e.args.Sig.UShortValue);
                    break;
            }

        }
    }
}