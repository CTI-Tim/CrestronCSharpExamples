﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomEventArgs
{
    class Program
    {
        static void Main(string[] args)
        {
            WorkingClass wc = new WorkingClass();
        }
    }

    class WorkingClass
    {
        // This is an object of the class that derives from EventArgs
        // Declared globally to allow access throughout WorkingClass
        CustomArgs ca = new CustomArgs();

        public WorkingClass()
        {
            // Create an object of whichever class is hosting the event
            EventDetails ed = new EventDetails();

            // Subscribe to the event
            ed.myEventToRun += Ed_myEventToRun;

            // Set custom arguments and trigger event to test
            AssignCustomArgs(1111, "I am first!");
            ed.MethodToTriggerEvent(ca); // Needed some way to trigger event

            // Set custom arguments and trigger event to test
            AssignCustomArgs(2222, "I am second!");
            ed.MethodToTriggerEvent(ca); // Needed some way to trigger event

            Console.Read();
        }

        private void Ed_myEventToRun(object sender, CustomArgs e)
        {
            //Console.WriteLine("Event was raised!");

            // Take incoming arguments and display values
            Console.WriteLine("Incoming data; number = {0}, text = {1}"
                , e.NumericValue, e.StringValue);
        }

        // Method to populate CustomArgs properties
        void AssignCustomArgs(int number, string text)
        {
            ca.NumericValue = number;
            ca.StringValue = text;
        }
    }
}
