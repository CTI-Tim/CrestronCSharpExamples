﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomEventArgs
{
    class EventDetails
    {
        // void EventHandler<TEventArgs>(object sender, TEventArgs e);
        public event EventHandler<CustomArgs> myEventToRun;

        protected virtual void onEventTrigger(CustomArgs e)
        {
            if (myEventToRun != null)
            {
                myEventToRun(this, e);
            }
        }

        // This method represents any possible requirement to raise
        // the event. Data comes from any source that creates an 
        // object of CustomArgs Class, assigns values to the 
        // properties and passes them to onEventTrigger.
        public void MethodToTriggerEvent(CustomArgs custom)
        {
            onEventTrigger(custom); 
        }
    }

    class CustomArgs : EventArgs // .NET guidelines
    {
        public int NumericValue { get; set; }
        public string StringValue { get; set; }
    }
}
