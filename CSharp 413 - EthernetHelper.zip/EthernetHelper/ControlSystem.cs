using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.UI;
using System;


namespace EthernetHelper
{
    public class ControlSystem : CrestronControlSystem
    {
        Tsw1060 myPanel;

        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                // Adding custom console commands to trigger methods while the program is running
                CrestronConsole.AddNewConsoleCommand(PrintOptionsForEthernetSettings, "printop", "printing functionality",
                    ConsoleAccessLevelEnum.AccessAdministrator);
                CrestronConsole.AddNewConsoleCommand(PrintIPInformationforConnectedDevice, "printip", "printing IP Addresses",
                    ConsoleAccessLevelEnum.AccessAdministrator);
                CrestronConsole.AddNewConsoleCommand(AddToPortMapping, "addmap", "update port mapping >addmap \"outside port\" \"inside port\"" +
                    "\"IP\" \"protocol\"", ConsoleAccessLevelEnum.AccessAdministrator);

                myPanel = new Tsw1060(0xf6, this);
                if (myPanel.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                {
                    ErrorLog.Error("Failure in panel registration. Reason = {0}", myPanel.RegistrationFailureReason);
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        void PrintOptionsForEthernetSettings(string args)
        {
            int numPorts = this.NumberOfEthernetAdapters;
            CrestronConsole.PrintLine("Adapter Count: {0}", numPorts);

            // Get valid adapter IDs. Attempts on invalid adapters will throw an exception.
            CrestronConsole.PrintLine("\rPrinting Adapter IDs:\r");

            CrestronConsole.PrintLine("LAN Adapter ID = {0}",
                CrestronEthernetHelper.GetAdapterdIdForSpecifiedAdapterType(EthernetAdapterType.EthernetLANAdapter));
            CrestronConsole.PrintLine("CS Adapter ID = {0}",
                CrestronEthernetHelper.GetAdapterdIdForSpecifiedAdapterType(EthernetAdapterType.EthernetCSAdapter));

            CrestronConsole.PrintLine("\rPrinting CrestronEthernetHelper parameters:\r\r" +
                "Hostname = {0}\r" +
                "CIPPORT = {1}\r" +
                "CTPPORT = {2}\r" +
                "LAN DHCP State = {3}\r" +
                "LAN IP Address = {4}\r" +
                "LAN Subnet Mask = {5}\r" +
                "LAN Default Router = {6}\r" +
                "LAN DNS Server = {7}\r\r" +
                "IsControlSubnetInAutomaticMode = {8}\r" +
                "Router Prefix = {9}.  [This will show all 0's if CS is in auto mode]\r" +
                "CS IP Address = {10}\r" +
                "CS Subnet Mask = {11}\r" +
                "CS Default Router = {12}\r" +
                "CS DNS Server = {13}\r",
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_HOSTNAME, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CIP_PORT, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CTP_PORT, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_DHCP_STATE, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_IP_ADDRESS, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_IP_MASK, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_ROUTER, 0),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_DNS_SERVER, 0),
                CrestronEthernetHelper.IsControlSubnetInAutomaticMode,
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CONTROL_SUBNET_ROUTER_PREFIX, 1),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_IP_ADDRESS, 1),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_IP_MASK, 1),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_CURRENT_ROUTER, 1),
                CrestronEthernetHelper.GetEthernetParameter(CrestronEthernetHelper.ETHERNET_PARAMETER_TO_GET.GET_DNS_SERVER, 1));

            // GetEthernetParameter allows information gathering.
            // SetEthernetParameter allows customization of settings for dynamically configuring the processor.
        }

        // Check connections with console command >who
        // Trigger console output with custom console command >printip
        void PrintIPInformationforConnectedDevice(string args)
        {
            foreach (var item in CrestronEthernetHelper.GetListOfConnectedIpAddressesForIPID(myPanel.ID))
            {
                CrestronConsole.PrintLine("Device connected to IPID {0} (dec) has IP address = {1}", myPanel.ID, item);
            }
        }

        // Check current port map list with console command >showportmap
        // Trigger console output with custom console command >addmap "outside port" "inside port" "IP" "protocol"
        void AddToPortMapping(string args)
        {
            string[] argsList = args.Split(' ');    // splitting on the space between the entered arguments
            ushort outerPort = ushort.Parse(argsList[0]);   // may need additional validation
            ushort innerPort = ushort.Parse(argsList[1]);   // may need additional validation
            CrestronEthernetHelper.ePortMapTransport protocol = CrestronEthernetHelper.ePortMapTransport.TCP; // setting default value for protocol

            if (argsList[2].ToUpper() == "TCP")
                protocol = CrestronEthernetHelper.ePortMapTransport.TCP;
            else if (argsList[2].ToUpper() == "UDP")
                protocol = CrestronEthernetHelper.ePortMapTransport.UDP;
            else
                ErrorLog.Error("Unsupported protocol requested, defaulting to TCP.");

            if (outerPort > 1024 && outerPort < 64000 && innerPort > 1024 && innerPort < 64000 && IPAddress.Parse(argsList[2]) != null)
            {
                CrestronEthernetHelper.AddPortForwarding(outerPort, innerPort, argsList[2], protocol);
            }
            else
                ErrorLog.Error("AddToPortMapping Data entry not Validated. Check parameters!");
        }
    }
}