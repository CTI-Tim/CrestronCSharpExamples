using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.DM.Streaming;              // For DM Streaming implementation such as NVX
using System;

namespace NVXSystem
{
    public class ControlSystem : CrestronControlSystem
    {
        // Reference to implementation link: https://help.crestron.com/SimplSharp/html/T_Crestron_SimplSharpPro_DM_Streaming_DmNvxControl.htm

        private DmNvx351 myNvxTxSource;
        private DmNvx351 myNvxRxDisplay;

        private DmNvx350 unknownNvxDevice;

        /// <summary>
        /// ControlSystem Constructor. Starting point for the SIMPL#Pro program.
        /// Use the constructor to:
        /// * Initialize the maximum number of threads (max = 400)
        /// * Register devices
        /// * Register event handlers
        /// * Add Console Commands
        /// 
        /// Please be aware that the constructor needs to exit quickly; if it doesn't
        /// exit in time, the SIMPL#Pro program will exit.
        /// 
        /// You cannot send / receive data in the constructor
        /// </summary>
        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                //Subscribe to the controller events (System, Program, and Ethernet)
                CrestronEnvironment.SystemEventHandler += new SystemEventHandler(_ControllerSystemEventHandler);
                CrestronEnvironment.ProgramStatusEventHandler += new ProgramStatusEventHandler(_ControllerProgramEventHandler);
                CrestronEnvironment.EthernetEventHandler += new EthernetEventHandler(_ControllerEthernetEventHandler);

                myNvxTxSource = new DmNvx351(0x10, this);
                myNvxTxSource.Description = "ClassRoom1 Source Device";
                myNvxTxSource.OnlineStatusChange += new OnlineStatusChangeEventHandler(NvxOnlineStatusChange);
                if (myNvxTxSource.Register() != eDeviceRegistrationUnRegistrationResponse.Success) 
                {
                    ErrorLog.Error("Error in Registering Device : {0}", myNvxTxSource.RegistrationFailureReason);
                }

                myNvxRxDisplay = new DmNvx351(0x11, this);
                myNvxRxDisplay.Description = "ClassRoom1 Display Device";
                myNvxTxSource.OnlineStatusChange += new OnlineStatusChangeEventHandler(NvxOnlineStatusChange);
                if (myNvxRxDisplay.Register() != eDeviceRegistrationUnRegistrationResponse.Success) 
                {
                    ErrorLog.Error("Error in Registering Device : {0}", myNvxRxDisplay.RegistrationFailureReason);
                }

                unknownNvxDevice = new DmNvx350(0x12, this);
                unknownNvxDevice.Description = "Unknown Device";
                myNvxTxSource.OnlineStatusChange += new OnlineStatusChangeEventHandler(NvxOnlineStatusChange);
                if (unknownNvxDevice.Register() != eDeviceRegistrationUnRegistrationResponse.Success) 
                {
                    ErrorLog.Error("Error in Registering Device : {0}", unknownNvxDevice.RegistrationFailureReason);
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        /// <summary>
        /// InitializeSystem - this method gets called after the constructor 
        /// has finished. 
        /// 
        /// Use InitializeSystem to:
        /// * Start threads
        /// * Configure ports, such as serial and verisports
        /// * Start and initialize socket connections
        /// Send initial device configurations
        /// 
        /// Please be aware that InitializeSystem needs to exit quickly also; 
        /// if it doesn't exit in time, the SIMPL#Pro program will exit.
        /// </summary>
        public override void InitializeSystem()
        {
            try
            {


            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        //Start the Processor when the end point go online
        void NvxOnlineStatusChange(GenericBase device, OnlineOfflineEventArgs args)
        {
            // checks if the transmitter is online
            if (device.ID == 0x10 && device.IsOnline)
            {
                // Enable automatic initiation so that the stream is started automatically when the multicast address is set
                // If you do not utilize the Automatic Initiaion Method, you will need to implement the start/stop method which is found on the documentation
                myNvxTxSource.Control.EnableAutomaticInitiation();

                // Enable Automatic Input routing so that when a source is detected, it will automatically be routed to the stream 
                myNvxTxSource.Control.EnableAutomaticInputRouting();

                // Reference OLH for multicast address range => https://support.crestron.com/app/answers/detail/a_id/1000264/kw/
                myNvxTxSource.Control.MulticastAddress.StringValue = "239.2.2.0";

                // check if the receiver is online
                if (device.ID == 0x11 && device.IsOnline)
                {
                    // enable automatic initiation so that when the stream URL is updated, it will start broadcasting the stream
                    // If you do not utilize the Automatic Initiaion Method, you will need to implement the start/stop method which is found on the documentaion
                    myNvxRxDisplay.Control.EnableAutomaticInitiation();

                    // setting the nvx receiver streaming Url to point to the transmitter streaming Url.
                    myNvxRxDisplay.Control.ServerUrl.StringValue = myNvxTxSource.Control.ServerUrlFeedback.StringValue;
                }
                else
                {
                    ErrorLog.Warn("Nvx Receiver is offline \r\n");
                }
            }
            else
            {
                ErrorLog.Warn("Nvx Transmitter is offline, cannot update the display \r\n");
            }

            // Working with the unknown device
            if (device.ID == 0x12 && device.IsOnline)
            {
                // This implementation allows you to change the NVX into a tx or rx mode and then reboot the device
                bool state = false;
                if (state)
                {
                    unknownNvxDevice.Control.DeviceMode = eDeviceMode.Receiver;       //property to set the device mode as a receiver
                }
                else
                {
                    unknownNvxDevice.Control.DeviceMode = eDeviceMode.Transmitter;  //property to set the device mode as transmitter
                }
                unknownNvxDevice.Control.Reboot();                                 //method to reboot the device
            }

        }

        /// <summary>
        /// Event Handler for Ethernet events: Link Up and Link Down. 
        /// Use these events to close / re-open sockets, etc. 
        /// </summary>
        /// <param name="ethernetEventArgs">This parameter holds the values 
        /// such as whether it's a Link Up or Link Down event. It will also indicate 
        /// wich Ethernet adapter this event belongs to.
        /// </param>
        void _ControllerEthernetEventHandler(EthernetEventArgs ethernetEventArgs)
        {
            switch (ethernetEventArgs.EthernetEventType)
            {//Determine the event type Link Up or Link Down
                case (eEthernetEventType.LinkDown):
                    //Next need to determine which adapter the event is for. 
                    //LAN is the adapter is the port connected to external networks.
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {
                        //
                    }
                    break;
                case (eEthernetEventType.LinkUp):
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {

                    }
                    break;
            }
        }

        /// <summary>
        /// Event Handler for Programmatic events: Stop, Pause, Resume.
        /// Use this event to clean up when a program is stopping, pausing, and resuming.
        /// This event only applies to this SIMPL#Pro program, it doesn't receive events
        /// for other programs stopping
        /// </summary>
        /// <param name="programStatusEventType"></param>
        void _ControllerProgramEventHandler(eProgramStatusEventType programStatusEventType)
        {
            switch (programStatusEventType)
            {
                case (eProgramStatusEventType.Paused):
                    //The program has been paused.  Pause all user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Resumed):
                    //The program has been resumed. Resume all the user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Stopping):
                    //The program has been stopped.
                    //Close all threads. 
                    //Shutdown all Client/Servers in the system.
                    //General cleanup.
                    //Unsubscribe to all System Monitor events
                    break;
            }

        }

        /// <summary>
        /// Event Handler for system events, Disk Inserted/Ejected, and Reboot
        /// Use this event to clean up when someone types in reboot, or when your SD /USB
        /// removable media is ejected / re-inserted.
        /// </summary>
        /// <param name="systemEventType"></param>
        void _ControllerSystemEventHandler(eSystemEventType systemEventType)
        {
            switch (systemEventType)
            {
                case (eSystemEventType.DiskInserted):
                    //Removable media was detected on the system
                    break;
                case (eSystemEventType.DiskRemoved):
                    //Removable media was detached from the system
                    break;
                case (eSystemEventType.Rebooting):
                    //The system is rebooting. 
                    //Very limited time to preform clean up and save any settings to disk.
                    break;
            }

        }
    }
}