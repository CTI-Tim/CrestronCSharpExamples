﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crestron.SimplSharpPro.UI; //  For Crestron Touch panels example in code 
//Do not forget your using statements and add your references

namespace CrestronHardwareClassExample
{
    class HardwareTemplate
    {
        // Containers for the Devices and internal variables and properties
        Tsw760 myTP;
        private uint DigitalID;
        private uint AnalogID;
        private uint SerialID;

        // Public Properties for the Class Interfacing
        // Remember that if you want to read information from a device, just use a getter with no setter.
        // read only properties are perfect for exposing device information
        public int MyProperty { get; set; }
        public int MyProperty2 { get; set; }

        // Example read only property that returns current touch panel on-line status
        public bool Online
        {
            get
            {
                return myTP.IsOnline;
            }
        }

        // Event Handler
        public event EventHandler<HardwareTemplateEventArgs> myEvent;

        // Default constructor that builds and sets up the device

        /// <summary>
        /// This is the summary information for the class you are creating for the device desired
        /// Be sure to put good information in here so that you or others can use the class sucessfully
        /// without having to open it and figure out how to use it
        /// </summary>
        /// <param name="id">The Id required for this device as a uint and typically Hex</param>
        /// <param name="cs">The control system it is connected to</param>
        /// <param name="FilenameForSG"></param>
        public HardwareTemplate(uint id, ControlSystem cs, string FilenameForSG)
        {
            // This example is a TSW 760 touch panel.  Do not try and make your hardware classes
            // too generic.  but simplify items if possible for more reuse ability.

            // Note add in code to detect if we can for the device (check for interface)
            // Check for success as well, throw an exception if unable to
            // This is the only way we can let the program know you were unable to register the device as
            // a default constructor does not have the ability to return information

            // Note: Touch panel is ONLY FOR AN EXAMPLE  this template  can be used for any hardware or any code
            myTP = new Tsw760(id, cs);              // Create our instance
            myTP.Register();                        // Register our Touch panel

            myTP.SigChange += MyTP_SigChange;       // Register our SigChange Event
            myTP.OnlineStatusChange += MyTP_OnlineStatusChange;  // Register on line off line event
        }

        private void MyTP_OnlineStatusChange(Crestron.SimplSharpPro.GenericBase currentDevice, Crestron.SimplSharpPro.OnlineOfflineEventArgs args)
        {
            OnRaiseEvent(new HardwareTemplateEventArgs("OnlineOffline"));  //  Call our event handler
        }

        private void MyTP_SigChange(Crestron.SimplSharpPro.DeviceSupport.BasicTriList currentDevice, Crestron.SimplSharpPro.SigEventArgs args)
        {
            // Code to process signals here
            OnRaiseEvent(new HardwareTemplateEventArgs("SigChangeSigType"));  //  Call our event handler
            
        }

        // Event Handler
        protected virtual void OnRaiseEvent(HardwareTemplateEventArgs e)
        {
            EventHandler<HardwareTemplateEventArgs> raiseEvent = myEvent; // make a copy


            if (raiseEvent != null) // do we have subscribers?
            {
                e.Online = myTP.IsOnline; // Set any event variables

                raiseEvent(this, e);  // Fire the event
            }

        }
    }

    // Our Event custom event args class
    // you can add more properties here to expand what you may need for your event data to send back.
    
    class HardwareTemplateEventArgs
    {
        public HardwareTemplateEventArgs(string message)
        {
            Message = message;
        }
        public string Message { get; set; }
        public bool Online { get; set; }
        public bool ID { get; set; }

    }
}
