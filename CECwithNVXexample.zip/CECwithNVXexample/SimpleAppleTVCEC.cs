﻿namespace CECwithNVXexample
{
    public class SimpleAppleTVCEC
    {
        /*  this was completely ripped out of the Simple Windows CEC module
         *  You can convert a LOT of modules from simple to C# yourself.
         *
         *  Example: the select command is \x04\x44\x00
         *           that button will stay pressed until you send \x04\x45 to tell it to release
         *           in the Apple TV it will self repeat.
         *           reminder: not all devices work this way. You will have to program your CEC
         *           class to work how the target device behaves and wants the commands sent.
         *
         *           Some devices support bidirectional communication.
         *  
         */

        private readonly string _preamble = "\x04\x44";

        private readonly string[] _command = { "\x00", "\x01", "\x02", "\x03", "\x04", "\x0D", "\x10", "\x44" };

        public string CecCommand(CommandEnum command)
        {
            return _preamble + _command[(int)command];
        }

        public string CecRelease()
        {
            return "\x04\x45";
        }
        public enum CommandEnum
        {
            Select = 0,
            Up,
            Down,
            Left,
            Right,
            Menu,
            HomeMenu,
            PlayPause
        }
    }
}
