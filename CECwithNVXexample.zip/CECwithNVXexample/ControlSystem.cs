using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.DM.Streaming; // For Generic Device Support
using System;
using static Crestron.SimplSharpPro.DM.Audio;

namespace CECwithNVXexample
{
    public class ControlSystem : CrestronControlSystem
    {
        private DmNvx350 myNvx;
        private SimpleAppleTVCEC myATV;
        private AdvancedAppleTvCec myOtherATV;


        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }
        public override void InitializeSystem()
        {
            try
            {
                myATV = new SimpleAppleTVCEC();
                

                // Create our NVX Receiver
                myNvx = new DmNvx350(0x10, this);
                myNvx.BaseEvent += MyNvx_BaseEvent;
                myNvx.Register();

                //Basic Setup to be reciever and send hdmi1 to the hdmi output on startup
                myNvx.Control.DeviceMode = eDeviceMode.Receiver;
                myNvx.Control.VideoSource = eSfpVideoSourceTypes.Hdmi1;

                // we instantiate this here as we now have access to the StreamCEC.Send for Input1
                myOtherATV = new AdvancedAppleTvCec(myNvx.HdmiIn[1].StreamCec.Send);

                CrestronConsole.AddNewConsoleCommand(AtvCommand, "ATV", "Send an ATV command", ConsoleAccessLevelEnum.AccessOperator);
                CrestronConsole.AddNewConsoleCommand(AtvCommand2, "ATV2", "Send an ATV command", ConsoleAccessLevelEnum.AccessOperator);

            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        /* Reminder: this is how to use EXAMPLE CODE for sending CEC commands.  This is not a coding best practice that should be
         * replicated in production code.  you should always leverage classes and limit what you do in
         * Control system.  There is no tech support on this code, do not contact True Blue Support with
         * questions about what you see in here.
         *
         * CEC for NVX, DM, DMPS, and other crestron devices all work the same.  Look for StreamCEC on the
         * connections you want to leverage CEC control.
         *
         * If you were to use this with a remote, you would send the command on press and the release on the release
         *
         */

        // This uses the first simpler class and the methods below to send the data to the device.
        public void AtvCommand(string s)
        {
            var request = s.Trim().ToLower();
            if (request.Length < 1)
            {
                CrestronConsole.ConsoleCommandResponse(" Valid options are  select, up, down, left, right,menu,homemenu, play");
            }

            switch (request)
            {
                case "select":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.Select));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "up":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.Up));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "down":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.Down));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "left":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.Left));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "right":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.Right));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "menu":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.Menu));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "homemenu":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.HomeMenu));
                    CECSendInput(1, myATV.CecRelease());
                    break;

                case "play":
                    CECSendInput(1, myATV.CecCommand(SimpleAppleTVCEC.CommandEnum.PlayPause));
                    CECSendInput(1, myATV.CecRelease());
                    break;
            }
        }

        // This one uses the second more advanced class that is passing the object to the class
        public void AtvCommand2(string s)
        {
            var request = s.Trim().ToLower();
            if (request.Length < 1)
            {
                CrestronConsole.ConsoleCommandResponse(" Valid options are  select, up, down, left, right,menu,homemenu, play");
            }

            switch (request)
            {
                case "select":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.Select);
                    break;

                case "up":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.Up);
                    break;

                case "down":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.Down);
                    break;

                case "left":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.Left);
                    break;

                case "right":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.Right);
                    break;

                case "menu":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.Menu);
                    break;

                case "homemenu":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.HomeMenu);
                    break;

                case "play":
                    myOtherATV.PulseCommand(AdvancedAppleTvCec.CommandEnum.PlayPause);
                    break;
            }
        }


        // These would be methods in the Devices class to send the CEC strings if you wanted that contained
        // inside the device class.    WE do not have to use these if we program the device we want to control
        // differently and pass it the object for sending the data.

        public void CECSendInput(uint input, string s)
        {
            // set the encoding type to ASCII.  NOTE:  This is NOT C# ASCII but Crestron ASCII
            myNvx.HdmiIn[input].StreamCec.Send.StringEncoding = eStringEncoding.eEncodingASCII;
            myNvx.HdmiIn[input].StreamCec.Send.StringValue = s;
        }

        public void CECSendOutput(string s)
        {
            myNvx.HdmiOut.StreamCec.Send.StringEncoding = eStringEncoding.eEncodingASCII;
            myNvx.HdmiOut.StreamCec.Send.StringValue = s;
        }




        private void MyNvx_BaseEvent(GenericBase device, BaseEventArgs args)
        {
            // Check if the device is asking for a reboot and send the command to reboot.
            if (myNvx.Control.RebootRequiredFeedback.BoolValue)
            {
                myNvx.Control.Reboot();
            }
        }
    }
}