﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crestron.SimplSharp;
using Crestron.SimplSharpPro;

namespace CECwithNVXexample
{
    /*
     * Ok Why is this called advanced when it's not that advanced?
     * WE are passing an object to work with and using a timer to be non blocking to create a more
     * robust and complete class for the apple TV hardware.
     *
     * This delivers a nice comparison example of doing it two ways and the advantage of making the class
     * more self contained and how it cleans up the code.  This should help those just learning how
     * leveraging classes better will make your coding in C# faster and more maintainable.
     */

    internal class AdvancedAppleTvCec
    {
        private readonly string _preamble = "\x04\x44";
        private readonly string[] _command = { "\x00", "\x01", "\x02", "\x03", "\x04", "\x0D", "\x10", "\x44" };
        private StringInputSig _cecStringConnection;
        private CTimer _cecTimer;  // using the crestron.SimplSharp timer.  you can use System.Timer if you want on 4 series

        public enum CommandEnum
        {
            Select = 0,
            Up,
            Down,
            Left,
            Right,
            Menu,
            HomeMenu,
            PlayPause
        }

        /// <summary>
        /// When we instantiate the class we need to pass it the Connection to the ports
        /// CEC string object.  This will make it available inside of our class
        /// </summary>
        /// <param name="CecString">the CEC string object usually found as myDevice.HdmiInput[x].StreamCec.Send </param>
        public AdvancedAppleTvCec(StringInputSig CecString)
        {
            _cecStringConnection = CecString;
            _cecStringConnection.StringEncoding = eStringEncoding.eEncodingASCII;// set the object to use CrestronASCII
        }

        public void SendCommand(CommandEnum command)
        {
            _cecStringConnection.StringValue = _preamble + _command[(int)command];
        }

        public void SendRelease()
        {
            _cecStringConnection.StringValue = "\x04\x45";
        }

        public void PulseCommand(CommandEnum command)
        {
            SendCommand(command);
            _cecTimer = new CTimer(timerDone, 25);  //25ms
        }

        /* We use a timer to deliver a small delay between send of the command and the send of the release
         * This emulates  a user pressing and releasing a button.  Not all devices need this.  The apple TV
         * will happily accept the release command instantly after sending the command. but not all devices
         * function this way. this is included here as an example of how to delay the release command being sent.
         */
        private void timerDone(object o)  // cTimer wants to pass an object to the called method. we dont use it here
        {
            SendRelease();
            _cecTimer.Stop();
            _cecTimer.Dispose();
        }

    }
}
