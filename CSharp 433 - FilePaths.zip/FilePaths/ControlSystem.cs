using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharp.CrestronIO;
//using System.IO;

namespace FilePaths
{
    public class ControlSystem : CrestronControlSystem
    {
        // 4-Series File Reading

        // Common folder locations for file storage
        // - Application Directory (same app## folder as the running program)
        // - 'user' folder
        // - 'nvram' folder
        // - 'Removable Media'

        string appFileName = "AppFolderFile.txt";
        string userFileName = "UserFolderFile.txt";
        string nvramFileName = "NvramFolderFile.txt";
        string rmFileName = "RemovableMediaFile.txt";

        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                CrestronConsole.AddNewConsoleCommand(BuildPaths, "BuildFilePaths", "Output of filepath building",
                  ConsoleAccessLevelEnum.AccessAdministrator);
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        void ConsoleMethod(string incoming)
        {
            CrestronConsole.PrintLine("\rFilePath = {0}", incoming);

            if (File.Exists(incoming))
                CrestronConsole.PrintLine("File Found!");
            else
                CrestronConsole.PrintLine("File NOT Found!");
        }

        void BuildPaths(string args)
        {
            // Current Application Folder
            //string appFilePath = string.Format("{0}\\{1}", Directory.GetApplicationDirectory(), appFileName);
            string appFilePath = Path.Combine(Directory.GetApplicationDirectory(), appFileName);

            ConsoleMethod(appFilePath);

            // User Folder
            string userFilePath = string.Format("/user/{0}", userFileName);

            ConsoleMethod(userFilePath);

            // Nvram Folder
            string nvramFilePath = Path.Combine("/nvram", nvramFileName);

            ConsoleMethod(nvramFilePath);

            // Removable Media
            string[] contentsOfRm = Directory.GetFiles("/rm");  // name of location can be checked in Text Console >dir output
            CrestronConsole.PrintLine("\r---------------------------\r");
            foreach (var item in contentsOfRm)
            {
                CrestronConsole.PrintLine("File in folder = {0}", item);

                if (item == Path.Combine("/rm", rmFileName))
                {
                    ConsoleMethod(item);
                    CrestronConsole.PrintLine("");  // formatting
                }
            }
            CrestronConsole.PrintLine("\r---------------------------");
        }
    }
}