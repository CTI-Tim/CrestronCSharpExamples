using System;
using System.Text;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.UI;
using Crestron.SimplSharpPro.Thermostats;
using Crestron.SimplSharpPro.Keypads;

namespace CheckingIfSupports
{
    public class ControlSystem : CrestronControlSystem
    {
        // External Devices
        Tsw760 myPanel;                     // IP communication
        C2nCbdP myKeypad;                   // Cresnet
        ChvTstatex myThermostat;            // InfiNET EX (requires RF gateway either internal or external to processor)

        // Onboard Devices
        ComPort myComPort;                  // RS-232/422/485
        Relay myRelay;                      // Physical relay port
        IROutputPort myIrPort;              // Signal + ground connection
        Versiport myVersiport;              // Flexible I/O
        // These generic base objects are optional and can be used to simplify naming

        // Container for serial ComSpec
        ComPort.ComPortSpec myComSpec;      // ComSpec definition (not hardware)

        /// <summary>
        /// ControlSystem Constructor. Starting point for the SIMPL#Pro program.
        /// Use the constructor to:
        /// * Initialize the maximum number of threads (max = 400)
        /// * Register devices
        /// * Register event handlers
        /// * Add Console Commands
        /// 
        /// Please be aware that the constructor needs to exit quickly; if it doesn't
        /// exit in time, the SIMPL#Pro program will exit.
        /// 
        /// You cannot send / receive data in the constructor
        /// </summary>
        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                //Subscribe to the controller events (System, Program, and Ethernet)
                CrestronEnvironment.SystemEventHandler += new SystemEventHandler(_ControllerSystemEventHandler);
                CrestronEnvironment.ProgramStatusEventHandler += new ProgramStatusEventHandler(_ControllerProgramEventHandler);
                CrestronEnvironment.EthernetEventHandler += new EthernetEventHandler(_ControllerEthernetEventHandler);


                // Hardware Instantiation
                if (this.SupportsEthernet)
                {
                    myPanel = new Tsw760(0x03, this);
                    myPanel.Description = "Front Hall Panel";
                    // Subscribe to events, then register
                    if (myPanel.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        ErrorLog.Error("Error registering {0}, err = {1}", myPanel.Description, myPanel.RegistrationFailureReason); ;
                    }
                }
                else
                    ErrorLog.Error("Processor does not support Ethernet!");

                if (this.SupportsCresnet)
                {
                    myKeypad = new C2nCbdP(0x25, this);
                    // register as usual if supported
                }

                if (this.SupportsInternalRFGateway)
                {
                    // EX devices get added to external Gateways, then the Gateway is registered
                    // EX devices get added to internal Gateways, then the device itself is registered
                    // It is important to check if the processor supports an internal RF Gateway
                    // MC4 has an internal Gateway, VC-4 and most other processors do not

                    myThermostat = new ChvTstatex(0x1f, this.ControllerRFGatewayDevice);
                    if (myThermostat.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        // report error on failure
                    }
                }

                if (this.SupportsComPort)   // ports are exclusive per program
                {
                    // Simplify naming with generic base object to a particular 1's based ComPort
                    myComPort = this.ComPorts[1];

                    // Use a ComPortSpec object to apply protocol, baud rate, handshaking, etc after Registration
                    // Use built-in eNum values
                    myComSpec = new ComPort.ComPortSpec();
                    myComSpec.BaudRate = ComPort.eComBaudRates.ComspecBaudRate115200;
                    myComSpec.Protocol = ComPort.eComProtocolType.ComspecProtocolRS232;

                    if (!myComPort.Registered)
                    {
                        if (myComPort.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                        {
                            // report error on failure
                        }
                        else
                        {
                            // Apply ComSpec
                            myComPort.SetComPortSpec(myComSpec);
                        }
                    }

                    // Unlike external harware, this item is accessible directly without instantiation
                    // It is important to check if the hardware you are accessing through supports the port
                    // VC-4 will not have ComPorts onboard

                    // Direct access without simplification
                    if (this.ComPorts[2].Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        // report error on failure
                    }
                    else
                        this.ComPorts[2].SetComPortSpec(myComSpec);
                }

                if (this.SupportsIROut)     // ports are shared across all programs at once
                {
                    // Simplify naming with generic base object
                    myIrPort = this.IROutputPorts[1];

                    myIrPort.LoadIRDriver("\\NVRAM\\AppleTV.ir"); // example path
                }

                if (this.SupportsRelay)     // shared across all programs at once
                {
                    // Like ComPorts, relays need to be registered before use
                    // Check ToolTip or documentation for device specific details

                    // Simplify naming with generic base object
                    myRelay = this.RelayPorts[1];

                    if (myRelay.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        // report error on failure
                    }
                }

                if (this.SupportsVersiport)     // ports are shared across all programs at once
                {
                    // Requires registration
                    if (this.VersiPorts[1].Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                    {
                        // report error on failure
                    }
                    else
                    {
                        // Simplify naming and set configuration of port
                        myVersiport = this.VersiPorts[1];

                        myVersiport.SetVersiportConfiguration(eVersiportConfiguration.DigitalInput);
                    }
                }
                else if (this.SupportsDigitalInput)     // should this not be a versiport
                {
                    // register the port as a Digital Input
                }

                if (this.SupportsSwitcherInputs || this.SupportsSwitcherOutputs)
                {
                    // DMPS
                }

            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        /// <summary>
        /// InitializeSystem - this method gets called after the constructor 
        /// has finished. 
        /// 
        /// Use InitializeSystem to:
        /// * Start threads
        /// * Configure ports, such as serial and verisports
        /// * Start and initialize socket connections
        /// Send initial device configurations
        /// 
        /// Please be aware that InitializeSystem needs to exit quickly also; 
        /// if it doesn't exit in time, the SIMPL#Pro program will exit.
        /// </summary>
        public override void InitializeSystem()
        {
            try
            {
 
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        /// <summary>
        /// Event Handler for Ethernet events: Link Up and Link Down. 
        /// Use these events to close / re-open sockets, etc. 
        /// </summary>
        /// <param name="ethernetEventArgs">This parameter holds the values 
        /// such as whether it's a Link Up or Link Down event. It will also indicate 
        /// wich Ethernet adapter this event belongs to.
        /// </param>
        void _ControllerEthernetEventHandler(EthernetEventArgs ethernetEventArgs)
        {
            switch (ethernetEventArgs.EthernetEventType)
            {//Determine the event type Link Up or Link Down
                case (eEthernetEventType.LinkDown):
                    //Next need to determine which adapter the event is for. 
                    //LAN is the adapter is the port connected to external networks.
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {
                        //
                    }
                    break;
                case (eEthernetEventType.LinkUp):
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {

                    }
                    break;
            }
        }

        /// <summary>
        /// Event Handler for Programmatic events: Stop, Pause, Resume.
        /// Use this event to clean up when a program is stopping, pausing, and resuming.
        /// This event only applies to this SIMPL#Pro program, it doesn't receive events
        /// for other programs stopping
        /// </summary>
        /// <param name="programStatusEventType"></param>
        void _ControllerProgramEventHandler(eProgramStatusEventType programStatusEventType)
        {
            switch (programStatusEventType)
            {
                case (eProgramStatusEventType.Paused):
                    //The program has been paused.  Pause all user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Resumed):
                    //The program has been resumed. Resume all the user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Stopping):
                    //The program has been stopped.
                    //Close all threads. 
                    //Shutdown all Client/Servers in the system.
                    //General cleanup.
                    //Unsubscribe to all System Monitor events
                    break;
            }

        }

        /// <summary>
        /// Event Handler for system events, Disk Inserted/Ejected, and Reboot
        /// Use this event to clean up when someone types in reboot, or when your SD /USB
        /// removable media is ejected / re-inserted.
        /// </summary>
        /// <param name="systemEventType"></param>
        void _ControllerSystemEventHandler(eSystemEventType systemEventType)
        {
            switch (systemEventType)
            {
                case (eSystemEventType.DiskInserted):
                    //Removable media was detected on the system
                    break;
                case (eSystemEventType.DiskRemoved):
                    //Removable media was detached from the system
                    break;
                case (eSystemEventType.Rebooting):
                    //The system is rebooting. 
                    //Very limited time to preform clean up and save any settings to disk.
                    break;
            }

        }
    }
}