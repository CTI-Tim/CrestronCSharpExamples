﻿namespace ModernContractTests
{
    public class Class1
    {
    }
}
