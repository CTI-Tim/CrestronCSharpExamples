﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckingForNull
{
    class Program
    {
        static string[] xArray;
        static void Main(string[] args)
        {
            if (xArray == null)
            {
                CreateArray();
            }
            if (xArray[0] == null)
            {
                Console.WriteLine("xArray[0] is null");
            }
            else
            {
                Console.WriteLine("xArray[0] is not null, but is {0}", xArray[0]);
            }
            Console.Read();
        }
        static void CreateArray()
        {
            xArray = new string[3];
        }
    }
}
