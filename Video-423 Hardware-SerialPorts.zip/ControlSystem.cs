using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support
using Crestron.SimplSharpPro.Keypads;                   //For Keypad support

namespace SerialPorts
{
    public class ControlSystem : CrestronControlSystem   //inheriting from Crestron Base class CrestronControlSystem
    {
        private C2nCbfP myKeypad;     //Cresnet keypad to register


        public ControlSystem()    //Constructor which is the starting point of the code
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;

                //Subscribe to the controller events (System, Program, and Ethernet)
                CrestronEnvironment.SystemEventHandler += new SystemEventHandler(_ControllerSystemEventHandler);
                CrestronEnvironment.ProgramStatusEventHandler += new ProgramStatusEventHandler(_ControllerProgramEventHandler);
                CrestronEnvironment.EthernetEventHandler += new EthernetEventHandler(_ControllerEthernetEventHandler);
                //Keypad
                if (this.SupportsCresnet)  //Check cresnet supported or not
                {
                    myKeypad = new C2nCbfP(0x30, this);        //instantiate and assing a cresnet ID 30
                    myKeypad.ButtonStateChange += new ButtonEventHandler(myKeypad_ButtonStateChange);
                    if (myKeypad.Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                        ErrorLog.Error("Error registering keypad at ID: 0x30: {0}", myKeypad.RegistrationFailureReason);

                }

                if (this.SupportsComPort)      //If Processor supports ComPort
                {
                    //Com port #1 will send only from keypad trigger
                    if (this.ComPorts[1].Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                        ErrorLog.Error("Error Registering Com Port{0}: {1}", 1, ComPorts[1].DeviceRegistrationFailureReason);
                    else
                    {
                        this.ComPorts[1].SetComPortSpec(ComPort.eComBaudRates.ComspecBaudRate19200,
                                                        ComPort.eComDataBits.ComspecDataBits8,
                                                        ComPort.eComParityType.ComspecParityNone,
                                                        ComPort.eComStopBits.ComspecStopBits1,
                                                        ComPort.eComProtocolType.ComspecProtocolRS232,
                                                        ComPort.eComHardwareHandshakeType.ComspecHardwareHandshakeNone,
                                                        ComPort.eComSoftwareHandshakeType.ComspecSoftwareHandshakeNone,
                                                        false);

                    }

                    //Com port #2 will rx only & update keypad LED Feedback
                    this.ComPorts[2].SerialDataReceived += new ComPortDataReceivedEvent(ControlSystem_SerialDataReceived);
                    if (this.ComPorts[2].Register() != eDeviceRegistrationUnRegistrationResponse.Success)
                        ErrorLog.Error("Error Registering Com Port{0}: {1}", 2, ComPorts[2].DeviceRegistrationFailureReason);
                    else
                    {
                        this.ComPorts[2].SetComPortSpec(ComPort.eComBaudRates.ComspecBaudRate19200,
                                                        ComPort.eComDataBits.ComspecDataBits8,
                                                        ComPort.eComParityType.ComspecParityNone,
                                                        ComPort.eComStopBits.ComspecStopBits1,
                                                        ComPort.eComProtocolType.ComspecProtocolRS232,
                                                        ComPort.eComHardwareHandshakeType.ComspecHardwareHandshakeNone,
                                                        ComPort.eComSoftwareHandshakeType.ComspecSoftwareHandshakeNone,
                                                        false);
                    }






                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        
        public override void InitializeSystem()
        {
            try
            {

            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }


        //Event Handler for Keypad events: myKeypad_ButtonStateChange 
        void myKeypad_ButtonStateChange(GenericBase device, ButtonEventArgs args)
        {
            if (args.Button.State == eButtonState.Pressed)
            {
                switch (args.Button.Number)
                {
                    case 1:
                        ComPorts[1].Send("Str1");       //Send string

                        // You can call the method to send a generic string to any port number
                        // SendMessageToComPort(1, "Str1");
                        break;
                    case 2:
                        ComPorts[1].Send("Str2");      //Send String
                        break;
                    default:
                        CrestronConsole.PrintLine("This Key is Not Programmed: {0}", args.Button.Number);
                        break;
                }
            }
        }


        /*
         ****** Generic method to send a generic string to any comport number*****
        void SendMessageToComPort(ushort portNumber,  string messageToSend)
        {
            // will need to do some error checking on the processor to ensure you are sending to the correct port
            // for example you can send to port 6 on PRO4 but you cannot send to port 6 on CP4 
            ComPorts[portNumber].Send(messageToSend);
        }
        */

        /// Event Handler for com port events: ControlSystem_SerialDataReceived 
        /// Use these events to receive serial data 
        void ControlSystem_SerialDataReceived(ComPort ReceivingComPort, ComPortSerialDataEventArgs args)
        {
            if (ReceivingComPort == ComPorts[2])
            {
                CrestronConsole.PrintLine("Com Port 2 Received Data:'{0}'", args.SerialData);
                if (args.SerialData == "Str1")
                {
                    myKeypad.Feedbacks[2].State = false;
                    myKeypad.Feedbacks[1].State = true;
                }
                else if (args.SerialData == "Str2")
                {
                    myKeypad.Feedbacks[1].State = false;
                    myKeypad.Feedbacks[2].State = true;
                }
            }
        }

        void _ControllerEthernetEventHandler(EthernetEventArgs ethernetEventArgs)
        {
            switch (ethernetEventArgs.EthernetEventType)
            {//Determine the event type Link Up or Link Down
                case (eEthernetEventType.LinkDown):
                    //Next need to determine which adapter the event is for. 
                    //LAN is the adapter is the port connected to external networks.
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {
                        //
                    }
                    break;
                case (eEthernetEventType.LinkUp):
                    if (ethernetEventArgs.EthernetAdapter == EthernetAdapterType.EthernetLANAdapter)
                    {

                    }
                    break;
            }
        }

        
        void _ControllerProgramEventHandler(eProgramStatusEventType programStatusEventType)
        {
            switch (programStatusEventType)
            {
                case (eProgramStatusEventType.Paused):
                    //The program has been paused.  Pause all user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Resumed):
                    //The program has been resumed. Resume all the user threads/timers as needed.
                    break;
                case (eProgramStatusEventType.Stopping):
                    //The program has been stopped.
                    //Close all threads. 
                    //Shutdown all Client/Servers in the system.
                    //General cleanup.
                    //Unsubscribe to all System Monitor events
                    break;
            }

        }

        /// <summary>
        /// Event Handler for system events, Disk Inserted/Ejected, and Reboot
        /// Use this event to clean up when someone types in reboot, or when your SD /USB
        /// removable media is ejected / re-inserted.
        /// </summary>
        /// <param name="systemEventType"></param>
        void _ControllerSystemEventHandler(eSystemEventType systemEventType)
        {
            switch (systemEventType)
            {
                case (eSystemEventType.DiskInserted):
                    //Removable media was detected on the system
                    break;
                case (eSystemEventType.DiskRemoved):
                    //Removable media was detached from the system
                    break;
                case (eSystemEventType.Rebooting):
                    //The system is rebooting. 
                    //Very limited time to preform clean up and save any settings to disk.
                    break;
            }

        }
    }
}