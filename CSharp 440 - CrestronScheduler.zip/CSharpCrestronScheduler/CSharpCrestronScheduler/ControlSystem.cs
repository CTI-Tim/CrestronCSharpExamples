using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharp.Scheduler;                    // #### For scheduler Support
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using System;
using System.Collections.Generic;                       // #### Need This to access Lists

namespace CSharpCrestronScheduler
{
    public class ControlSystem : CrestronControlSystem
    {
        // Create our containers
        private ScheduledEventGroup myGroup;        // Container for the Scheduler Group

        private List<ScheduledEvent> myEvents = new List<ScheduledEvent>();  // Create a list of the events, this allows us to have more than one
        
        public ControlSystem()
            : base()
        {
            try
            {
                Thread.MaxNumberOfUserThreads = 20;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        public override void InitializeSystem()
        {
            try
            {
                // Setup the scheduler  you can check in the command line with SHOWALLEVENTS -I:ProgramName -G:TestGroup
                myGroup = new ScheduledEventGroup("TestGroup"); // We need to name the event group
                myGroup.RetrieveAllEvents();                    // You must retrieve them even though they will be read only.
                                                               
                CrestronConsole.PrintLine(" Loaded {0} events from the Group", myGroup.ScheduledEvents.Count);

                List<ScheduledEvent> oldEvents = new List<ScheduledEvent>();  //Create a Local temp list to get the old existing events

                // List out each and every event that was stored in our group in the scheduler
                foreach (var i in myGroup.ScheduledEvents)
                {
                    CrestronConsole.PrintLine(" Loaded Event {0}:{1} at {2}", i.Key, i.Value.Name, i.Value.DateAndTime);
                    oldEvents.Add(i.Value); // We add each old event into our oldevents list
                }
                myGroup.ClearAllEvents();  // Wipe out everything there as we need to recreate them to make sure they trigger our method

                // Now recreate each and every event so we can modify them and subscribe them to the event handler
                foreach (var i in oldEvents)
                    myAddEvent("old" + i.Name, i.Description, i.DateAndTime.Hour, i.DateAndTime.Minute, i.Recurrence.RecurrenceDays);
                    // Note:  We append "old" here because we auto generate 10 entries and they will conflict in name

                // Lets create a sequence of new Events all 1 minute apart

                for (var i = 1; i <= 10; i++)
                {
                    //
                    myAddEvent("Timer" + i.ToString(), "Description of timer " + i.ToString(),
                        DateTime.Now.Hour, DateTime.Now.Minute + i, ScheduledEventCommon.eWeekDays.All);
                }

                myListEvents();  //  Now list all the events we have created
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }



        public bool myAddEvent(string name, string description, int hour, int minute, ScheduledEventCommon.eWeekDays days)
        {
            // We need to use the DateTime Object to format the scheduled event date and time.
            // Most AV and Lighting scheduled event only care about the same time daily, so we make it for today.
            // If you need a scheduled event for a specific day and time you can specify that directly instead

            DateTime myDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, hour, minute, 00);

            //  Crestron scheduler will fail if we schedule an event for the past. so we need to check if the event is in the future
            if (myDate < DateTime.Now)      // Is it in the past even by a millisecond?
                myDate = myDate.AddDays(1); //  Add 1 day to make it the future.

            if (myGroup.ScheduledEvents.ContainsKey(name) == false) //no two events can be named the same
            {
                try
                {
                    // Create a new Scheduled event and wrap it inside a new entry to our list. Remember lists contain objects
                    // The line below uses the add method for the list to create a new entry, and we instantiate a new Scheduled Event inside that
                    // new list entry

                    myEvents.Add(new ScheduledEvent(name, myGroup));  // add a new event into our list

                    int eventNo = myEvents.Count - 1; // remember lists are 0 based  back up 1

                    myEvents[eventNo].Description = description;                // description field
                    myEvents[eventNo].Persistent = true;                        // Do not self delete after event fires
                    myEvents[eventNo].Acknowledgeable = false;                  // Do not make the event acknowledgeable
                    myEvents[eventNo].DateAndTime.SetAbsoluteEventTime(myDate); // Set the actual event time and date MUST DO THIS BEFORE Recurrence
                    myEvents[eventNo].Recurrence.Weekly(days);                  // Set what days it runs

                    myEvents[eventNo].UserCallBack += Event_Trigger_Callback;   // Event handler for when the Scheduled event fires

                    myEvents[eventNo].Enable();                                 // Enable the Event and make it live
                    return true;
                }
                catch (Exception e)
                {
                    CrestronConsole.PrintLine("Event creation failed reason  {0}", e.Message);
                    myEvents.RemoveAt(myEvents.Count - 1);                      // Delete the event as it's bad and threw an exception
                }
            }
            return false;
        }

        public void myListEvents()
        {
            CrestronConsole.PrintLine("----- Event List -----");
            foreach (var i in myEvents)
                CrestronConsole.PrintLine("Event: {0} at {1} in Group :{2}", i.Name, i.DateAndTime, i.EventGroup.Name);
        }

        private void Event_Trigger_Callback(ScheduledEvent SchEvent, ScheduledEventCommon.eCallbackReason type)
        {
            CrestronConsole.PrintLine("{0} Event: {1} with Desc: {2} Triggered with {3}", DateTime.Now, SchEvent.Name, SchEvent.Description, type);
        }
    }
}