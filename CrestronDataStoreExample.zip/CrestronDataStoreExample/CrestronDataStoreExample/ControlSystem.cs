using System;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.CrestronThread;        	// For Threading
using Crestron.SimplSharpPro.Diagnostics;		    	// For System Monitor Access
using Crestron.SimplSharpPro.DeviceSupport;         	// For Generic Device Support

using Crestron.SimplSharp.CrestronDataStore;            // For DataStore Access

namespace CrestronDataStoreExample
{
    public class ControlSystem : CrestronControlSystem
    {
        // This example is using a Simplified ControlSystem.cs for Clarity.
        public ControlSystem()
            : base()
        {
            try
            {
                CrestronConsole.AddNewConsoleCommand(DataStoreLocal, "DSL", "Load string to the LocalDataStore slot", ConsoleAccessLevelEnum.AccessOperator);
                CrestronConsole.AddNewConsoleCommand(DataStoreGlobal, "DSG", "Load string to the GlobalDataStore slot", ConsoleAccessLevelEnum.AccessOperator);

                Thread.MaxNumberOfUserThreads = 20;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in the constructor: {0}", e.Message);
            }
        }

        string MyLocalDataString = "";
        string MyGlobalDataString = "";
 
        public override void InitializeSystem()
        {
            try
            {

                //  The Crestron DataStore Class is a Static Class and we do not have to instantiate it
                // This does not have to be done here.  This can be done at any time and anywhere in your program.
                //  This MUST be done before you try to read or write to the DataStore

                CrestronDataStoreStatic.InitCrestronDataStore(); // We need to Initialize our DataStore
                // Set up our Global Access for other programs to access information stored
                CrestronDataStoreStatic.GlobalAccess = CrestronDataStore.CSDAFLAGS.OWNERREADWRITE & CrestronDataStore.CSDAFLAGS.OTHERREADWRITE;


            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        // Methods for Commands
        private void DataStoreLocal(string s)
        {
            if(s.Contains("-R"))  // User wants to read the datastore
            {
                var err = CrestronDataStoreStatic.GetLocalStringValue("LocalString", out MyLocalDataString);  // Try to retrieve the string stored at named storage LocalString
                
                if (err != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)  // Looking if we did not get Success back
                {
                    MyLocalDataString = "ERROR"; // Load the string with an error
                    CrestronConsole.PrintLine("Error Retrieving DataStore named \"LocalString\" with error {0}", err);
                }
                else
                {
                    CrestronConsole.ConsoleCommandResponse("DataStore Retrieved \"{0}\" from Local on Program Start", MyLocalDataString);
                }
            }

            else if(s.Contains("-W:")) // user wants to Write to the datastore
            {
                var message = s.Substring(3);

                // We write our string to the datastore specified.  we wrap it in a IF and check of we had any status returned that was not a success
                if (CrestronDataStoreStatic.SetLocalStringValue("LocalString", message) != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)
                {
                    CrestronConsole.ConsoleCommandResponse("Error Storing String to Local DataStore.");  // Failed
                }
                else
                    CrestronConsole.ConsoleCommandResponse("Stored to Local DataStore.");  // Success

            }
            else if(s.Contains("-D"))  //User wants to delete the datastore
            {
                // Using the clearLocal method we also check if it was not successful
                if (CrestronDataStoreStatic.clearLocal("LocalString") != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)  //. Check if we are not equal to success
                {
                    CrestronConsole.ConsoleCommandResponse("Failed to clear local datastore");  //Failed
                }
                else
                    CrestronConsole.ConsoleCommandResponse("Success clearing local datastore"); //Success

            }
            else   // If the user does not specify a flag we send them the "help" information.
            {
                CrestronConsole.ConsoleCommandResponse("DSL:\x0d\x0a -R = read the datastore\x0d\x0a -W:Message to store in text form = write to the localdatastore\x0d\x0a-D = clear or delete the datastore\x0d\x0a");
                
            }
        }

        private void DataStoreLocalDelete(string s)
        {
            if( CrestronDataStoreStatic.clearLocal("LocalString") != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)
            {
                CrestronConsole.ConsoleCommandResponse("Failed to clear local datastore");
            }
            else
                CrestronConsole.ConsoleCommandResponse("Success clearing local datastore");

        }

        private void DataStoreGlobal(string s)
        {
            if (s.Contains("-R"))  // Read the datastore
            {
                var err = CrestronDataStoreStatic.GetGlobalStringValue("GlobalString", out MyGlobalDataString);  // Try to retrieve the string stored at named storage LocalString

                if (err != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)  // Looking if we did not get Success back
                {
                    MyGlobalDataString = "ERROR"; // Load the string with an error
                    CrestronConsole.PrintLine("Error Retrieving DataStore named \"GlobalString\" with error {0}", err);
                }
                else
                {
                    CrestronConsole.ConsoleCommandResponse("Global DataStore Retrieved \"{0}\" from Local on Program Start", MyGlobalDataString);
                }
            }

            else if (s.Contains("-W:")) // Write to the datastore
            {
                var message = s.Substring(3);

                if (CrestronDataStoreStatic.SetGlobalStringValue("GlobalString", message) != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)
                {
                    CrestronConsole.ConsoleCommandResponse("Error Storing String to Global DataStore");
                }
                
            }
            else if (s.Contains("-D"))  //DELETE the datastore
            {
                if (CrestronDataStoreStatic.clearGlobal("GLobalString") != CrestronDataStore.CDS_ERROR.CDS_SUCCESS)
                {
                    CrestronConsole.ConsoleCommandResponse("Failed to clear global datastore");
                }
                else
                    CrestronConsole.ConsoleCommandResponse("Success clearing global datastore");

            }
            else
            {
                CrestronConsole.ConsoleCommandResponse("DSG:\x0d\x0a -R = read the datastore\x0d\x0a -W:Message to store in text form = write to the datastore\x0d\x0a-D = Clear or Delete the datastore\x0d\x0a");

            }
        }

    }
}