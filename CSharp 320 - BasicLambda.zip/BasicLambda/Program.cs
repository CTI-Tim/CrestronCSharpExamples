﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicLambda
{
    class Program
    {
        static void Main(string[] args)
        {
            DataSet data = new DataSet();

            // Iterate over the entire collection and print to console
            //foreach (var item in data.NvxModels)
            //{
            //    Console.WriteLine("NVX Model = {0}", item);
            //}

            // Find index for a particular model.
            // Pseudocode: "Return the index of the value matching "DM-NVX-E30"
            // int index = data.NvxModels.IndexOf("DM-NVX-E30");

            // Applying a Lambda Expression in place of a Predicate to assist in the search.
            // A Predicate is a delegate. ie. a contract to adhere to for a method's signature
            // A Lambda Expression uses the => operator to separate input parameters
            // and the Expression.
            // The Expression needs to return a boolean value (true/false) to satisfy the
            // Predicate if the object to compare against meets the conditions defined.

            // Pseudocode: "Return the item index where the item value at index equals "DM-NVX-E30"
            int index = data.NvxModels.FindIndex(p => p.Equals("DM-NVX-E30"));
                                // input parameter => expression to evaluate

            // p is the 'item index' or 'what I'm looking for based on the FindIndex method'.
            // => is the 'where' (Lambda Expression).

            Console.WriteLine("NVX Model {0} found at index = {1}", data.NvxModels[index], index);

            // More complicated lookup;
            // Pseudocode: "Find the index of the last item with '60' in the name:.
            // int lastIndex = data.NvxModels.LastIndexOf("60");
            // Fails as LastIndexOf is looking for an exact string match.

            // Possible solution - lengthy
            //int lastIndex = -1;
            //foreach (var item in data.NvxModels)
            //{
            //    if (item.Contains("60"))
            //    {
            //        lastIndex = data.NvxModels.IndexOf(item);
            //    }
            //}

            // Applying a Lambda Expression
            int lastIndex = data.NvxModels.FindLastIndex(p => p.Contains("60"));

            Console.WriteLine("Last NVX model with '60' in name is at index = {0}", lastIndex);


            Console.Read();
        }
    }
}
