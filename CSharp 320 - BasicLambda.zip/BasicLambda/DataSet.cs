﻿using System.Collections.Generic;

namespace BasicLambda
{
    class DataSet
    {
        public DataSet() 
        {
            EnterModels(); 
        }

        public List<string> NvxModels 
            = new List<string>();

        void EnterModels()
        {                                       // Index
            NvxModels.Add("DM-NVX-350");        // 0
            NvxModels.Add("DM-NVX-350C");       // 1
            NvxModels.Add("DM-NVX-351");        // 2
            NvxModels.Add("DM-NVX-351C");       // 3
            NvxModels.Add("DM-NVX-352");        // 4
            NvxModels.Add("DM-NVX-352C");       // 5
            NvxModels.Add("DM-NVX-360");        // 6
            NvxModels.Add("DM-NVX-360C");       // 7
            NvxModels.Add("DM-NVX-363");        // 8
            NvxModels.Add("DM-NVX-363C");       // 9
            NvxModels.Add("DM-NVX-E760");       // 10
            NvxModels.Add("DM-NVX-E760C");      // 11
            NvxModels.Add("DM-NVX-D30");        // 12
            NvxModels.Add("DM-NVX-D30C");       // 13
            NvxModels.Add("DM-NVX-E30");        // 14 
            NvxModels.Add("DM-NVX-E30C");       // 15
            NvxModels.Add("DM-NVX-D80-IOAV");   // 16
        }
    }
}
